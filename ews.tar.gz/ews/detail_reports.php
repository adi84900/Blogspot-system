<?php
ob_start();
session_start();
if(!$_SESSION['userid']){
   header("location:index.php");
   die;
}
include_once('config/config.php');
include_once('config/php_mysql_class.php');
include_once('config/function.php');
//$page = (int) $_GET['page'];
$page = isset($_GET['page']) ? mysql_real_escape_string($_GET['page']) : 0;
if ($page < 1) $page = 1;
$numberOfPages = 5;
$resultsPerPage = 10;
$startResults = ($page - 1) * $resultsPerPage;
$mysql = new mysql();
 $user_name=$_SESSION['userid'];
 $userid= $_SESSION['userid'];
 $user_types=$_SESSION['user_type'];
 //echo $user_types;
   if(isset($_REQUEST['filter_submit']))
 {
		 
		  $bu_unit=$_GET['business_unit'];
		  $department=$_GET['department'];
		  $manager_name=$_GET['manager_detail'];
		  $supervisor_name=$_GET['supervisor_detail'];
		  $emp_id=$_GET['emp_id'];
		  $fromdate_filter=$_GET['fromdate_filter'];
		  $todate_filter=$_GET['todate_filter'];
		  if($bu_unit==0)
		  {
		  $bu_unit='';
		  }
		   if($department==0)
		  {
		  $department='';
		  }
		   if($manager_name==0)
		  {
		  $manager_name='';
		  }
		  if($supervisor_name==0)
		  {
		  $supervisor_name='';
		  }
		  if($emp_id==0)
		  {
		  $emp_id='';
		  }
		  if($fromdate_filter!='' && $todate_filter!='')
		  {
		   
		   $fromdate_filter= date("Y-m-d h:m:s", strtotime($fromdate_filter));
		   $todate_filter= date("Y-m-d  h:m:s", strtotime($todate_filter));
		   $condition = "(`business_unit` LIKE '%$bu_unit%' AND `department` LIKE '%$department%'  AND `manager_detail` LIKE '%$manager_name%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%') AND created_date between '$fromdate_filter' and '$todate_filter'";
		  }
		  else
		  {
		  $condition = "`business_unit` LIKE '%$bu_unit%' AND `department` LIKE '%$department%'  AND `manager_detail` LIKE '%$manager_name%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%'";
		  }
       $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition'=> $condition,'order'=>'created_date DESC'));
	   $totalPages = ceil($numberOfRows / $resultsPerPage);
       $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
 }
 elseif(isset($_GET['manager_detail']) && $_GET['manager_detail']!=0)
 {
          $bu_unit=$_GET['business_unit'];
		  $department=$_GET['department'];
		  $manager_name=$_GET['manager_detail'];
		  $supervisor_name=$_GET['supervisor_detail'];
		  $month=explode(' ',$_GET['month']);
          $year=$_GET['year'];
		  $condition = "`business_unit` LIKE '%$bu_unit%' AND `department` LIKE '%$department%'  AND `manager_detail` LIKE '%$manager_name%' AND `supervisor_detail` LIKE '%$supervisor_name%'  AND month(created_date)='$month[0]' and year(created_date)='$year'";
		   $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition'=> $condition,'order'=>'created_date DESC'));
	       $totalPages = ceil($numberOfRows / $resultsPerPage);
		  $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
 }
 else {
 $condition ="(`one_on_one_ass` + `performance` + `leave_r` + `external_interviews` + `behavior_motivation` + `personal_effectiveness` + `career_growth` + `skill_set`) >36"; 
 $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition'=> $condition,'order'=>'created_date DESC'));
 $totalPages = ceil($numberOfRows / $resultsPerPage);
 $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'1=1' ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
 }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Detail Report | Quatrro Caveat</title>
<?php include_once('includes/allcss.php'); ?>
</head>
<body class="hold-transition skin-green-light sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once('includes/leftside.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Detail Report </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Detail Report</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            <div class="box-body">
              <div class="row">
                <form action="" method="get" name="userews">
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>Business Unit<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="business_unit" onChange="getdepartment(this.value)" class="form-control select2" id="business_unit">
                        <option value="" selected="selected">Select BU</option>
                         <?php 
					
					$show_bu=  $mysql->select(array('table'=>'business_name','fields'=>'*'));
					foreach($show_bu as $key=>$value)
					{
					?>
                    <option value="<?php echo $value['business_name']['business_code']; ?>" <?php if(isset($_GET['business_unit'])){if($_GET['business_unit']==$value['business_name']['business_code']) echo "selected";}?>> <?php echo $value['business_name']['business_name']; ?> </option>
                    <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="department_div">
                      <label>Department<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="department" class="form-control select2" id="department">
                        <option value="" selected="selected">Select Department</option>
						 <?php 
				 $bu_id=$_GET['business_unit'];
				 $department=  $mysql->select(array('table'=>'department_master','fields'=>'*','condition'=>'INSTR (business_unit, '.$bu_id.')','order'=>'department_name'));
				  foreach($department as $key=>$value)
					 {
				 ?>
                      <option value="<?php echo $value['department_master']['id']; ?>" <?php if(isset($_GET['department'])){if($_GET['department']==$value['department_master']['id']) echo "selected";}?>> <?php echo $value['department_master']['department_name']."(".$value['department_master']['department_code'].")"; ?> </option>
                      <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="manager_div">
                      <label>Manager Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="manager_detail" class="form-control select2" id="manager_detail">
                        <option value="" selected="selected">Select Manager</option>
						 <?php 
				 $bu_id_new=$_GET['business_unit'];
				 $department_id_new=$_GET['department'];
				 $manager_detail_new=$_GET['manager_detail'];
				 $manager_name_new=  $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and department='.$department_id_new.' and user_type in(3,4) and status=0','order'=>'first_name'));
				  foreach($manager_name_new as $key=>$valueuser)
					 {
				 ?>
                      <option value="<?php echo $valueuser['users']['user_id']; ?>" <?php if(isset($_GET['manager_detail'])){if($_GET['manager_detail']==$valueuser['users']['user_id']) echo "selected";}?>> <?php echo $valueuser['users']['first_name'].' '. $valueuser['users']['last_name']."(".$valueuser['users']['username'].")"; ?> </option>
                      <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="am_dm_div">
                      <label>AM/DM Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="supervisor_detail" class="form-control select2" id="supervisor_detail">
                        <option value="" selected="selected">Select AM/DM</option>
						<?php 
				 $bu_id_new=$_GET['business_unit'];
				 $department_id_new=$_GET['department'];
				 $manager_detail_new=$_GET['manager_detail'];
				 $amdm_detail_new=$_GET['supervisor_detail'];
				 $manager_ids=$mysql->get('users','username','user_id='.$manager_detail_new);
				 $supervisor_name_new= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and department='.$department_id_new.' and manager_id LIKE "%'.$manager_ids.'%" and user_type!=6 and status=0','order'=>'first_name'));
				  foreach($supervisor_name_new as $key=>$valuesupervisor)
					 {
				 ?>
                      <option value="<?php echo $valuesupervisor['users']['user_id']; ?>" <?php if(isset($_GET['supervisor_detail'])){if($_GET['supervisor_detail']==$valuesupervisor['users']['user_id']) echo "selected";}?>> <?php echo $valuesupervisor['users']['first_name'].' '. $valuesupervisor['users']['last_name']."(".$valuesupervisor['users']['username'].")"; ?> </option>
                      <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="employee_div">
                      <label>Employee Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="emp_id" class="form-control select2" id="emp_id">
                        <option value="" selected="selected">Select Employee</option>
						<?php 
				 $bu_id_new=$_GET['business_unit'];
				 $department_id_new=$_GET['department'];
				 $manager_detail_new=$_GET['manager_detail'];
				 $amdm_detail_new=$_GET['supervisor_detail'];
				 $emp_detail_new=$_GET['emp_id'];
				 $manager_ids=$mysql->get('users','username','user_id='.$amdm_detail_new);
				 $supervisor_name_new= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and department='.$department_id_new.' and manager_id LIKE "%'.$manager_ids.'%" and user_type=6 and status=0','order'=>'first_name'));
				  foreach($supervisor_name_new as $key=>$valuesupervisor)
					 {
				 ?>
                      <option value="<?php echo $valuesupervisor['users']['user_id']; ?>" <?php if(isset($_GET['emp_id'])){if($_GET['emp_id']==$valuesupervisor['users']['user_id']) echo "selected";}?>> <?php echo $valuesupervisor['users']['first_name'].' '. $valuesupervisor['users']['last_name']."(".$valuesupervisor['users']['username'].")"; ?> </option>
                      <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>From</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="from" type="text" name="fromdate_filter" value="<?php if(isset($_GET['fromdate_filter'])){ echo $_GET['fromdate_filter'];}?>">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>To</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="to" type="text" name="todate_filter" value="<?php if(isset($_GET['todate_filter'])){ echo $_GET['todate_filter'];}?>">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-1" style="padding-top:25px;">
                    <div class="form-group">
                      <button class="btn btn-success" type="submit" name="filter_submit"><span class="fa fa-search" aria-hidden="true"></span> Go</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="box box-success">
            <div class="box-body table-responsive no-padding">
              <table class="table table-bordered table-striped">
                <tbody>
                  <tr>
                   <th><strong style="float:left; width:180px;"> Business Unit Name</strong></th>
                    <th><strong style="float:left; width:120px;">Employee Code</strong></th>
                    <th ><strong style="float:left; width:120px;">Employee Name</strong></th>
                    <th><strong style="float:left; width:150px;">Team Lead's Name</strong></th>
                    <th ><strong style="float:left; width:150px;">Month of Assessment</strong></th>
                    <th ><strong style="float:left; width:150px;">Employee Department</strong></th>
                    <th ><strong style="float:left; width:100px;">Joining Date</strong></th>
                    <th ><strong style="float:left; width:100px;">Grade</strong></th>
                    <th ><strong style="float:left; width:100px;">Last Promo date</strong></th>
                    <th ><strong style="float:left; width:220px;">Tenure in Current Position (Months)</strong></th>
                    <th ><strong style="float:left; width:100px;">Tenure in Days</strong></th>
                    <th ><strong style="float:left; width:100px;">Tenure in Months</strong></th>
                    <th ><strong style="float:left; width:100px;">Tenure in Years</strong></th>
                    <th ><strong style="float:left; width:100px;">1 on 1 assessment</strong></th>
                    <th ><strong style="float:left; width:100px;">Performance</strong></th>
                    <th ><strong style="float:left; width:70px;">Leave</strong></th>
                    <th ><strong style="float:left; width:120px;">External Interviews</strong></th>
                    <th ><strong style="float:left; width:150px;">Behavior/ Motivation</strong></th>
                    <th ><strong style="float:left; width:150px;">Personal Effectiveness</strong></th>
                    <th ><strong style="float:left; width:100px;">Career Growth</strong></th>
                    <th ><strong style="float:left; width:100px;">Skill Set</strong></th>
                    <th ><strong style="float:left; width:130px;">Formulated Rating</strong></th>
                    <th ><strong style="float:left; width:100px;">Template Rating</strong></th>
                    <th ><strong style="float:left; width:100px;">Q-PEP Rating</strong></th>
                    <th ><strong style="float:left; width:100px;">Criticality Check</strong></th>
                    <th ><strong style="float:left; width:250px;">Comments</strong></th>
                    <th ><strong style="float:left; width:250px;">Action Plan</strong></th>
                  </tr>
                   <?php
							  
							    foreach($users_ews as $key=>$value_ews)
									 {
									$bu_ids= $value_ews['ews_detail']['business_unit'];
									$department= $value_ews['ews_detail']['department'];
									$emp_id= $value_ews['ews_detail']['emp_id'];
									$id= $value_ews['ews_detail']['id'];
								 ?>
                  <tr>
                    <td width="auto"><?php
								$business_name=$mysql->get('business_name','business_name','business_code='.$bu_ids);
								echo $business_name;
								?>
                    </td>
                    <?php 
								
								$first_name=$mysql->get('users','first_name','user_id='.$emp_id);
								$last_name=$mysql->get('users','last_name','user_id='.$emp_id);
								$username=$mysql->get('users','username','user_id='.$emp_id);
								//echo $first_name.' '.$last_name.'('.$username.')';
								 ?>
                    <td><?php echo $username; ?></td>
                    <td class="center "><?php echo $first_name.' '.$last_name; ?></td>
                    <td><?php 
								
								$manager_name=$mysql->get('users','manager_name','user_id='.$emp_id);
								$manager_id=$mysql->get('users','manager_id','user_id='.$emp_id);
								echo $manager_name;
								?></td>
                    <td><?php echo date('d M Y', strtotime($value_ews['ews_detail']['assesment_month'])); ?></td>
                    <td class="center "><?php
								$department=$mysql->get('department_master','department_name','id='.$department);
								echo $department;
								?></td>
                    <td><?php 
								
								$doj=$mysql->get('users','doj','user_id='.$emp_id);
								echo date('d M Y',$doj); 
								
								?></td>
                    <td><?php
								$grade=$mysql->get('users','grade','user_id='.$emp_id);
								echo $grade;
								?></td>
                    <td > N/A </td>
                    <td > N/A </td>
                    <td > N/A </td>
                    <td > N/A </td>
                    <td > N/A </td>
                    <?php
	
	if($value_ews['ews_detail']['one_on_one_ass'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['one_on_one_ass'] >= 3 && $value_ews['ews_detail']['one_on_one_ass'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['one_on_one_ass'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;" ><?php echo $value_ews['ews_detail']['one_on_one_ass']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['performance'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['performance'] >= 3 && $value_ews['ews_detail']['performance'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['performance'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;" ><?php echo $value_ews['ews_detail']['performance']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['leave_r'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['leave_r'] >= 3 && $value_ews['ews_detail']['leave_r'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['leave_r'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['leave_r']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['external_interviews'] < 3)
	{
	$colors="#FF0000";
	}

	else if($value_ews['ews_detail']['external_interviews'] >= 3 && $value_ews['ews_detail']['external_interviews'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['external_interviews'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['external_interviews']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['behavior_motivation'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['behavior_motivation'] >= 3 && $value_ews['ews_detail']['behavior_motivation'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['behavior_motivation'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['behavior_motivation']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['personal_effectiveness'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['personal_effectiveness'] >= 3 && $value_ews['ews_detail']['personal_effectiveness'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['personal_effectiveness'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['personal_effectiveness']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['career_growth'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['career_growth'] >= 3 && $value_ews['ews_detail']['career_growth'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['career_growth'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['career_growth']; ?></td>
                    <?php
	
	if($value_ews['ews_detail']['skill_set'] < 3)
	{
	$colors="#FF0000";
	}
	else if($value_ews['ews_detail']['skill_set'] >= 3 && $value_ews['ews_detail']['skill_set'] < 5 )
	{
	$colors="#FF9933";
	}
	else if($value_ews['ews_detail']['skill_set'] ==5)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php echo $value_ews['ews_detail']['skill_set']; ?></td>
                    <td><?php 
	  $total_rating=$value_ews['ews_detail']['one_on_one_ass']+$value_ews['ews_detail']['skill_set']+$value_ews['ews_detail']['career_growth']+$value_ews['ews_detail']['personal_effectiveness'] +$value_ews['ews_detail']['behavior_motivation'] +$value_ews['ews_detail']['external_interviews']+$value_ews['ews_detail']['leave_r'] +$value_ews['ews_detail']['performance'];
	  echo $total_rating;
	?></td>
                    <?php
	
	if($total_rating <= 36)
	{
	$colors="#FF0000";
	}
	else if($total_rating  > 36 && $total_rating  <= 38 )
	{
	$colors="#FF9933";
	}
	else if($total_rating >= 39)
	{
	$colors="#006600";
	}
	
	?>
                    <td style="background:<?php echo $colors; ?>; color:#FFFFFF; font-weight:bold; text-align:center;"><?php  echo $total_rating; ?></td>
                    <td>N/A</td>
                    <td>N/A</td>
                    <td><?php echo $value_ews['ews_detail']['comment']; ?></td>
                    <td><?php echo $value_ews['ews_detail']['action_plan']; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <?php $halfPages = floor($numberOfPages / 2);
					$range = array('start' => 1, 'end' => $totalPages);
					$isEven = ($numberOfPages % 2 == 0);
					$atRangeEnd = $totalPages - $halfPages;
					
					if($isEven) $atRangeEnd++;
					
					if($totalPages > $numberOfPages)
					{
						if($page <= $halfPages)
							$range['end'] = $numberOfPages;
						elseif ($page >= $atRangeEnd)
							$range['start'] = $totalPages - $numberOfPages + 1;
						else
						{
							$range['start'] = $page - $halfPages;
							$range['end'] = $page + $halfPages;
							if($isEven) $range['end']--;
						}
					} if($totalPages>1) {  
			   if(isset($_REQUEST['filter_submit']))
                  {		?>
              <ul class="pagination pagination-sm no-margin pull-right">
                <?php if($page > 1)
					echo '<li class="button"><a href="'.$_SERVER['REQUEST_URI'].'&page='.($page - 1).'">&laquo; Previous</a>&nbsp<li>';
				
				for ($i = $range['start']; $i <= $range['end']; $i++)
				{
					if($i == $page)
						echo '<li class="active"><a class="current" href="#">'.$i.'</a></li>';
					else
						echo ' <li><a href="'.$_SERVER['REQUEST_URI'].'&page='.$i.'">'.$i.'</a> </li>';
				}
				if ($page < $totalPages)
					echo ' <li class="button"><a href="'.$_SERVER['REQUEST_URI'].'&page='.($page + 1).'">Next &raquo; </a></li>'; ?>
              </ul>
              <?php } else { ?>
              <ul class="pagination pagination-sm no-margin pull-right">
                <?php if($page > 1)
					echo '<li class="button"><a href="?page='.($page - 1).'">&laquo; Previous</a>&nbsp<li>';
				
				for ($i = $range['start']; $i <= $range['end']; $i++)
				{
					if($i == $page)
						echo '<li class="active"><a class="current" href="#">'.$i.'</a></li>';
					else
						echo ' <li><a href="?page='.$i.'">'.$i.'</a> </li>';
				}
				if ($page < $totalPages)
					echo ' <li class="button"><a href="?page='.($page + 1).'">Next &raquo; </a></li>'; ?>
              </ul>
              <?php } 
			       } ?>
            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <?php include_once('includes/footer.php'); ?>
</div>
<!-- ./wrapper -->
<?php include_once('includes/alljs.php'); ?>
</body>
</html>
