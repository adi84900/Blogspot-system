<?php
ob_start();
session_start();
if(!$_SESSION['userid']){
   header("location:index.php");
   die;
}
include_once('config/config.php');
include_once('config/php_mysql_class.php');

include_once('config/function.php');
/*echo '<pre>';
print_r($_SESSION);
echo '</pre>';*/
$mysql=new mysql();
if (isset($_REQUEST['submit'])) 
{
	/* echo '<pre>';
	 print_r($_POST);
	  echo '</pre>';
	 die();*/
	 $business_unit=$_POST['business_unit'];
	 $department=$_POST['department']; 
	 $manager_detail=$_POST['manager_detail']; 
	 $supervisor_detail=$_POST['supervisor_detail']; 
	 $emp_id=$_POST['emp_id']; 
	 $assesment_month=$_POST['assesment_month']; 
	 $meeting_date=$_POST['meeting_date']; 
	 $one_on_one_ass=$_POST['one_on_one_ass']; 
	 $performance=$_POST['performance']; 
	 $leave_r=$_POST['leave_r']; 
	 $external_interviews=$_POST['external_interviews']; 
	 $behavior_motivation=$_POST['behavior_motivation']; 
	 $personal_effectiveness=$_POST['personal_effectiveness']; 
	 $career_growth=$_POST['career_growth']; 
	 $skill_set=$_POST['skill_set'];
	 $criticality_check=$_POST['criticality_check']; 
	 $attrition_date=$_POST['attrition_date']; 
	 $action_plan=$_POST['action_plan']; 
	 $comment=$_POST['comment'];
	 $on_notice=$_POST['on_notice'];
	 
	 $redeployment=$_POST['redeployment']; 
	 $marriage=$_POST['marriage']; 
	 $night_shift=$_POST['night_shift']; 
	 $family_problems=$_POST['family_problems']; 
	 $salary=$_POST['salary']; 
	 $higher_education=$_POST['higher_education']; 
	 $medical_problems=$_POST['medical_problems']; 
	 $warnings=$_POST['warnings']; 
	 $maternity=$_POST['maternity']; 
	 
	 $regular_pattern=$_POST['regular_pattern'];
	 $inconsistent_efforts=$_POST['inconsistent_efforts']; 
	 $improves_productivity=$_POST['improves_productivity']; 
	 $lack_of_interest=$_POST['lack_of_interest']; 
	 $leaves=$_POST['leaves'];
	 $forgets_key_meetings=$_POST['forgets_key_meetings'];
	 $late_comings=$_POST['late_comings'];
	 $dressing=$_POST['dressing']; 
	 $creativity=$_POST['creativity']; 
	 $energy_issue=$_POST['energy_issue']; 
	 $unrealistic_issue=$_POST['unrealistic_issue'];
	 $spreads_negativity=$_POST['spreads_negativity'];
	 $excitement_issue=$_POST['excitement_issue']; 
	 $arrogant=$_POST['arrogant']; 
	 $appraisal_issue=$_POST['appraisal_issue'];
	 $attending_interviews=$_POST['attending_interviews'];
	 $permissions=$_POST['permissions'];
	 
	 foreach ($emp_id as $i => $emp) {
	   $employee = $emp;
       $assesmentmonth_new = $assesment_month[$i];
	   $meetingdate_new=$meeting_date[$i]; 
	   $oneononeass_new=$one_on_one_ass[$i]; 
	   $perf_new=$performance[$i]; 
	   $leaver_new=$leave_r[$i]; 
	   $externalinterviews_new=$external_interviews[$i]; 
	   $behaviormotivation_new=$behavior_motivation[$i]; 
	   $personaleffectiveness_new=$personal_effectiveness[$i]; 
	   $careergrowth_new=$career_growth[$i]; 
	   $skillset_new=$skill_set[$i]; 
	   $criticality_check_new=$criticality_check[$i]; 
	   $attrition_date_new=$attrition_date[$i]; 
	   $actionplan_new=mysql_real_escape_string($action_plan[$i]); 
	   $comment_new=mysql_real_escape_string($comment[$i]);
	   $on_notice_new=$on_notice[$i];
	   
	   $redeployment=$redeployment[$i]; 
	   $marriage=$marriage[$i]; 
	   $night_shift=$night_shift[$i]; 
	   $family_problems=$family_problems[$i]; 
	   $salary=$salary[$i]; 
	   $higher_education=$higher_education[$i]; 
	   $medical_problems=$medical_problems[$i]; 
	   $warnings=$warnings[$i]; 
	   $maternity=$maternity[$i]; 
	   
	     $regular_pattern=$regular_pattern[$i];
		 $inconsistent_efforts=$inconsistent_efforts[$i]; 
		 $improves_productivity=$improves_productivity[$i]; 
		 $lack_of_interest=$lack_of_interest[$i]; 
		 $leaves=$leaves[$i];
		 $forgets_key_meetings=$forgets_key_meetings[$i];
		 $late_comings=$late_comings[$i];
		 $dressing=$dressing[$i]; 
		 $creativity=$creativity[$i]; 
		 $energy_issue=$energy_issue[$i]; 
		 $unrealistic_issue=$unrealistic_issue[$i];
		 $spreads_negativity=$spreads_negativity[$i];
		 $excitement_issue=$excitement_issue[$i]; 
		 $arrogant=$arrogant[$i]; 
		 $appraisal_issue=$appraisal_issue[$i];
		 $attending_interviews=$attending_interviews[$i];
		 $permissions=$permissions[$i];
	   
	   $mysql=new mysql();
	   $emp_city=$mysql->get('users','city','user_id='.$employee);
	   $emp_department=$mysql->get('users','department','user_id='.$employee);
	   $mysql=new mysql();
	   $ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'assesment_month="'.$assesmentmonth_new.'" AND emp_id='.$employee));
	   if(empty($ews_detail))
		{
	     $total_rating=$oneononeass_new+$perf_new+$leaver_new+$externalinterviews_new+$behaviormotivation_new+$personaleffectiveness_new+$careergrowth_new+$skillset_new;	
	     if($total_rating <= 23)
		{
		  $status  = 1;
		}
		else if($total_rating   >= 24 && $total_rating  <= 29 )
		{
		  $status = 2;
		}
		else if($total_rating >= 30)
		{
		  $status = 3;
		}
	   $mysql = "INSERT INTO ews_detail (business_unit, department, manager_detail, supervisor_detail, emp_id, assesment_month, meeting_date,one_on_one_ass,performance,leave_r,external_interviews,behavior_motivation,personal_effectiveness,career_growth,skill_set,criticality_check,location,comment,action_plan,attrition_date,created_date,status,on_notice)
					 VALUES ('$business_unit', '$emp_department', '$manager_detail', '$supervisor_detail', '$employee', '$assesmentmonth_new', '$meetingdate_new', '$oneononeass_new', '$perf_new', '$leaver_new', '$externalinterviews_new', '$behaviormotivation_new', '$personaleffectiveness_new', '$careergrowth_new', '$skillset_new', '$criticality_check_new','$emp_city','$comment_new','$actionplan_new','$attrition_date_new',NOW(),'$status','$on_notice_new')";
	  mysql_query($mysql,$dbhandle) or die(mysql_error());
	  $last_id = mysql_insert_id($dbhandle);
	 if($oneononeass_new==1) {
	 $mysql_oneononeAssessment = "INSERT INTO 1on1assessment_details (business_unit, department, manager_detail, supervisor_detail,emp_id, ews_id, redeployment, marriage, night_shift, family_problems, salary,higher_education,medical_problems	,warnings,maternity,date_added_on)
					 VALUES ('$business_unit', '$emp_department', '$manager_detail', '$supervisor_detail','$employee', '$last_id', '$redeployment', '$marriage', '$night_shift', '$family_problems', '$salary', '$higher_education', '$medical_problems', '$warnings', '$maternity',NOW())";
	  mysql_query($mysql_oneononeAssessment,$dbhandle) or die(mysql_error());
	  }
	 if($behaviormotivation_new==1) { 
	 $mysql_behaviorial_details = "INSERT INTO behaviorial_details (business_unit, department, manager_detail, supervisor_detail,emp_id, ews_id, regular_pattern, inconsistent_efforts, improves_productivity, lack_of_interest, leaves,forgets_key_meetings,late_comings,dressing,creativity,energy_issue,unrealistic_issue,spreads_negativity,excitement_issue,arrogant,appraisal_issue,attending_interviews,permissions,added_on)
					 VALUES ('$business_unit', '$emp_department', '$manager_detail', '$supervisor_detail','$employee', '$last_id', '$regular_pattern', '$inconsistent_efforts', '$improves_productivity', '$lack_of_interest', '$leaves', '$forgets_key_meetings','$late_comings', '$dressing', '$creativity', '$energy_issue', '$unrealistic_issue', '$spreads_negativity','$excitement_issue', '$arrogant', '$appraisal_issue', '$attending_interviews', '$permissions',NOW())";
	  mysql_query($mysql_behaviorial_details,$dbhandle) or die(mysql_error());
	 }
	 
	  if($mysql)
	  {
	  // echo $mysql.'<br />';
	  $_SESSION['error_msg'] = '<div class="alert alert-success alert-dismissible">Employee Parichay added successfully.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon fa fa-close"></i> </button></div>';
	//  header("location: add_ews.php");
	  }
	 }
	 }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Add Employee Retention | Retention</title>
<?php include_once('includes/allcss.php'); ?>
</head>
<body class="hold-transition skin-green-light sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php
			 if($_SESSION['user_type']==1) {
				include('includes/leftside_admin.php');
			 } elseif($_SESSION['user_type']==3) {
				include('includes/leftside_hr.php');
			 } elseif($_SESSION['user_type']==4) {
			  include('includes/leftside_amdm.php');
		  } elseif($_SESSION['user_type']==5) {
			   include('includes/leftside_manager.php');
		  } 
	   ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Retention <small>The fields marked with <span style="color:#FF0000; font-weight:bold"><sup>*</sup></span> are mandatory.</small></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo BASE_URL; ?>/dashboard.php"><i class="fa fa-dashboard"></i> My Dashboard</a></li>
        <li class="active">Add Retention</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <?php
			if(isset($_SESSION['error_msg'] ))
			{  ?>
        <div class="col-md-12"> <?php echo $_SESSION['error_msg'];  ?> </div>
        <?php 
		  unset($_SESSION['error_msg']);
			}
			?>
        <form enctype="multipart/form-data" name="add_ews" action="" method="post" id="add_ews">
          <input type="hidden" name="business_unit" id="business_unit" value="<?php echo $_SESSION['business_unit']; ?>">
          <input type="hidden" name="department" id="department" value="<?php echo $_SESSION['department']; ?>">
          <input type="hidden" name="manager_detail" id="manager_detail" value="<?php echo $_SESSION['manager_id']; ?>">
          <input type="hidden" name="supervisor_detail" id="supervisor_detail" value="<?php echo $_SESSION['userid']; ?>">
          <input type="hidden" id="starting_emp" value="2">
          <div class="col-md-12" style="display:none;" id="employee_last_pie_records">
            <div class="box box-success">
			  <div class="box-header with-border">
				  <label class="box-title" id="employeename_display">Behavior/ Motivation</label>
				  <div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
				  </div>
				  <!-- /.box-tools -->
				</div>
              <div class="box-body">
                <div class="col-md-4" style="display:none;" id="employee_last2lastmonth_pie_records">
                  <div class="box-body">
                    <div class="third circle"> <strong id="thirdcircle"></strong> <span><?php echo date('F, Y', strtotime('first day of -2 month'));?></span> </div>
                  </div>
                </div>
                <div class="col-md-4" style="display:none;" id="employee_lastmonth_pie_records">
                  <div class="box-body">
                    <div class="second circle"> <strong id="secondcircle"></strong> <span><?php echo date('F, Y', strtotime('first day of -1 month'));?></span> </div>
                  </div>
                </div>
                <div class="col-md-4" style="display:none;" id="employee_current_pie_records">
                  <div class="box-body">
                    <div class="first circle">
                      <div id="firstcircle"></div>
                      <span>Current</span> </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="col-md-3">
              <div class="box box-success">
                <div class="box-body">
                  <div class="form-group" id="employee_div">
                    <label>Employee Name<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                    <select name="emp_id[]" class="form-control select2 EmpLevel" id="emp_id_1" onChange="getvalemployeeID(this);">
                      <option value="" selected="selected">Select</option>
                      <?php 
								 $bu_id=$_SESSION['business_unit'];
								 $department_id=$_SESSION['department'];
								 $manager_id=$_SESSION['username'];
								 $mysql=new mysql();
								 $employee_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id.' and manager_id LIKE "%'.$manager_id.'%" and status=0 and user_type=6','order'=>'first_name'));
								  foreach($employee_list as $key=>$valuesemployee)
									 {
								 $ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'YEAR(assesment_month) = YEAR(CURRENT_DATE()) AND MONTH(assesment_month) = MONTH(CURRENT_DATE()) AND emp_id='.$valuesemployee['users']['user_id'].' and business_unit='.$bu_id.' and supervisor_detail ='.$supervisor_detail.''));
									   if(empty($ews_detail)) { ?>
                      <option value="<?php echo $valuesemployee['users']['user_id']; ?>"> <?php echo $valuesemployee['users']['first_name'].' '. $valuesemployee['users']['last_name']."(".$valuesemployee['users']['username'].")"; ?> </option>
                      <?php  }
							  } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Month Of Assesment<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                    <div class="input-group date">
                      <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                      <input class="form-control pull-right" id="assesment_month" type="text" name="assesment_month[]">
                    </div>
                    <!-- /.input group -->
                  </div>
                  <div class="form-group">
                    <label>Meet Up Date<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                    <div class="input-group date">
                      <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                      <input class="form-control pull-right" id="meeting_date" type="text" name="meeting_date[]">
                    </div>
                    <!-- /.input group -->
                  </div>
                  <div class="form-group">
                    <label>Attrition Date
                    <!--<span style="color:#dd4b39; font-weight:bold"><sup>*</sup>-->
                    </span></label>
                    <div class="input-group date">
                      <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                      <input class="form-control pull-right" id="attrition_date" type="text" name="attrition_date[]">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="box box-success">
                <div class="box-body">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>On Notice </span></label>
                      <br />
                      <input type="radio" name="on_notice[]" class="flat-green" value="1" checked>
                      No &nbsp;
                      <input type="radio" name="on_notice[]" class="flat-red" value="2">
                      Yes </div>
                    <div class="form-group">
                      <label>Performance<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="performance[]" class="flat-red performance" value="1" id="performance" checked="checked">
                      1 &nbsp;
                      <input type="radio" name="performance[]" class="flat-orange performance" value="3" id="performance">
                      3 &nbsp;
                      <input type="radio" name="performance[]" class="flat-green performance" value="5" id="performance">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>Leave<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="leave_r[]" class="flat-red leave_r" value="1" checked id="leave_r">
                      1 &nbsp;
                      <input type="radio" name="leave_r[]" class="flat-orange leave_r" value="3" id="leave_r">
                      3 &nbsp;
                      <input type="radio" name="leave_r[]" class="flat-green leave_r" value="5" id="leave_r">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>External Interviews<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="external_interviews[]" class="flat-red external_interviews" value="1" checked id="external_interviews">
                      1 &nbsp;
                      <input type="radio" name="external_interviews[]" class="flat-orange external_interviews" value="3" id="external_interviews">
                      3 &nbsp;
                      <input type="radio" name="external_interviews[]" class="flat-green external_interviews" value="5" id="external_interviews">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>Personal Effectiveness<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="personal_effectiveness[]" class="flat-red personal_effectiveness" value="1" checked id="personal_effectiveness">
                      1 &nbsp;
                      <input type="radio" name="personal_effectiveness[]" class="flat-orange personal_effectiveness" value="3" id="personal_effectiveness">
                      3 &nbsp;
                      <input type="radio" name="personal_effectiveness[]" class="flat-green personal_effectiveness" value="5" id="personal_effectiveness">
                      5 &nbsp; </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Career Growth<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="career_growth[]" class="flat-red career_growth" value="1" checked id="career_growth">
                      1 &nbsp;
                      <input type="radio" name="career_growth[]" class="flat-orange career_growth" value="3" id="career_growth">
                      3 &nbsp;
                      <input type="radio" name="career_growth[]" class="flat-green career_growth" value="5" id="career_growth">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>Skill Set<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="skill_set[]" class="flat-red skill_set" value="1" checked id="skill_set">
                      1 &nbsp;
                      <input type="radio" name="skill_set[]" class="flat-orange skill_set" value="3" id="skill_set">
                      3 &nbsp;
                      <input type="radio" name="skill_set[]" class="flat-green skill_set" value="5" id="skill_set">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>1 ON 1 Assessment<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="one_on_one_ass[]" class="flat-red one_on_one_ass" value="1"  id="one_on_one_ass">
                      1 &nbsp;
                      <input type="radio" name="one_on_one_ass[]" class="flat-orange one_on_one_ass" value="3" checked id="one_on_one_ass">
                      3 &nbsp;
                      <input type="radio" name="one_on_one_ass[]" class="flat-green one_on_one_ass" value="5" id="one_on_one_ass">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>Behavior/ Motivation<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="behavior_motivation[]" class="flat-red behavior_motivation" value="1" id="behavior_motivation">
                      1 &nbsp;
                      <input type="radio" name="behavior_motivation[]" class="flat-orange behavior_motivation" value="3" id="behavior_motivation">
                      3 &nbsp;
                      <input type="radio" name="behavior_motivation[]" class="flat-green behavior_motivation" value="5" checked id="behavior_motivation">
                      5 &nbsp; </div>
                    <div class="form-group">
                      <label>Criticality<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                      <br />
                      <input type="radio" name="criticality_check[]" class="flat-red" value="1" checked>
                      High&nbsp;
                      <input type="radio" name="criticality_check[]" class="flat-orange" value="2">
                      Medium&nbsp;
                      <input type="radio" name="criticality_check[]" class="flat-green" value="3">
                      Low&nbsp; </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="box box-success">
                <div class="box-body">
                  <div class="form-group">
                    <label>Action Plan<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                    <textarea name="action_plan[]" id="action_plan" class="form-control" rows="4"></textarea>
                  </div>
                  <div class="form-group">
                    <label>Comment/Remark<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                    <textarea name="comment[]" id="comment" class="form-control" rows="4"></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12" id="additional_id" style="display:none;">
            <div class="box box-success">
			  <div class="box-header with-border">
				  <label class="box-title">1 ON 1 Assessment</label>
				  <div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
				  </div>
				  <!-- /.box-tools -->
				</div>
              <div class="box-body">
                <div id="one_on_one_ass_form" style="display:none;">
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Redeployment<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="redeployment[]" class="flat-red" value="1" checked>
                        Unmatched role or department <br/>
                        <input type="radio" name="redeployment[]" class="flat-orange" value="3">
                        May not be happy in current profile <br/>
                        <input type="radio" name="redeployment[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Marriage in offering<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="marriage[]" class="flat-red" value="1" checked>
                        Wedding commitment <br/>
                        <input type="radio" name="marriage[]" class="flat-orange" value="3">
                        Probable wedding commitment <br/>
                        <input type="radio" name="marriage[]" class="flat-green" value="5">
                        No issues
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Night shift<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="night_shift[]" class="flat-red" value="1" checked>
                        Rotational shift <br/>
                        <input type="radio" name="night_shift[]" class="flat-orange" value="3">
                        May not rotational shift <br/>
                        <input type="radio" name="night_shift[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Family problems<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="family_problems[]" class="flat-red" value="1" checked>
                        Stringent to fix hours <br/>
                        <input type="radio" name="family_problems[]" class="flat-orange" value="3">
                        Insist to fix working hours <br/>
                        <input type="radio" name="family_problems[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Salary<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="salary[]" class="flat-red" value="1" checked>
                        Unsatisfactory remuneration <br/>
                        <input type="radio" name="salary[]" class="flat-orange" value="3">
                        Unahppy with salary <br/>
                        <input type="radio" name="salary[]" class="flat-green" value="5">
                        No issues
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Higher education<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="higher_education[]" class="flat-red" value="1" checked>
                        Ambitious for higher study <br/>
                        <input type="radio" name="higher_education[]" class="flat-orange" value="3">
                        Seeking opprtunity for higher study <br/>
                        <input type="radio" name="higher_education[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Medical problems<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="medical_problems[]" class="flat-red" value="1" checked>
                        Frequent medical issues <br/>
                        <input type="radio" name="medical_problems[]" class="flat-orange" value="3">
                        Manageable medical issues <br/>
                        <input type="radio" name="medical_problems[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Warnings - diciplinary, behavioural<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="warnings[]" class="flat-red" value="1" checked>
                        Disciplinary issues <br/>
                        <input type="radio" name="warnings[]" class="flat-orange" value="3">
                        Open for feedback to work uopn <br/>
                        <input type="radio" name="warnings[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Maternity<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="maternity[]" class="flat-red" value="1" checked>
                        Unplanned leaves before maternity <br/>
                        <input type="radio" name="maternity[]" class="flat-orange" value="3">
                        Child care responsibility <br/>
                        <input type="radio" name="maternity[]" class="flat-green" value="5">
                        No issues </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12" id="additional_id_new" style="display:none;">
            <div class="box box-success">
		   	 <div class="box-header with-border">
				  <label class="box-title">Behavior/ Motivation</label>
				  <div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
				  </div>
				  <!-- /.box-tools -->
				</div>
              <div class="box-body">
                <div id="behaviorial_details_form" style="display:none;">
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Regular pattern in taking leaves<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="regular_pattern[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="regular_pattern[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="regular_pattern[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="regular_pattern[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="regular_pattern[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Inconsistent efforts in productivity<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="inconsistent_efforts[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="inconsistent_efforts[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="inconsistent_efforts[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="inconsistent_efforts[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="inconsistent_efforts[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Performance dips again<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="improves_productivity[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="improves_productivity[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="improves_productivity[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="improves_productivity[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="improves_productivity[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Lack of interest in participating<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="lack_of_interest[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="lack_of_interest[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="lack_of_interest[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="lack_of_interest[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="lack_of_interest[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Leaves for lunch alone<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="leaves[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="leaves[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="leaves[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="leaves[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="leaves[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Forgets key meetings<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="forgets_key_meetings[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="forgets_key_meetings[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="forgets_key_meetings[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="forgets_key_meetings[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="forgets_key_meetings[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Late comings<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="late_comings[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="late_comings[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="late_comings[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="late_comings[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="late_comings[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Lack of interest in dressing up for work<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="dressing[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="dressing[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="dressing[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="dressing[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="dressing[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Not coming out with new ideas/creativity<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="creativity[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="creativity[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="creativity[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="creativity[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="creativity[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Shows lack of energy<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="energy_issue[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="energy_issue[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="energy_issue[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="energy_issue[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="energy_issue[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Being unrealistic in expecting growth<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="unrealistic_issue[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="unrealistic_issue[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="unrealistic_issue[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="unrealistic_issue[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="unrealistic_issue[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Is an energy vamp. Spreads negativity<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="spreads_negativity[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="spreads_negativity[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="spreads_negativity[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="spreads_negativity[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="spreads_negativity[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Shows sudden cheer or excitement around<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="excitement_issue[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="excitement_issue[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="excitement_issue[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="excitement_issue[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="excitement_issue[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Gets more bold and a little arrogant<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="arrogant[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="arrogant[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="arrogant[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="arrogant[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="arrogant[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Is not keen in appraisal/ hike<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="appraisal_issue[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="appraisal_issue[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="appraisal_issue[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="appraisal_issue[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="appraisal_issue[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Dressing indicates attending interviews<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="attending_interviews[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="attending_interviews[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="attending_interviews[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="attending_interviews[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="attending_interviews[]" class="flat-green" value="5">
                        5&nbsp;
                        <!-- /.input group -->
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Permissions - To attend Interviews<span style="color:#dd4b39; font-weight:bold"><sup>*</sup></span></label>
                        <br/>
                        <input type="radio" name="permissions[]" class="flat-red" value="1" checked>
                        1 &nbsp;
                        <input type="radio" name="permissions[]" class="flat-yellow" value="2">
                        2 &nbsp;
                        <input type="radio" name="permissions[]" class="flat-orange" value="3">
                        3&nbsp;
                        <input type="radio" name="permissions[]" class="flat-aero" value="4">
                        4&nbsp;
                        <input type="radio" name="permissions[]" class="flat-green" value="5">
                        5&nbsp; </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <button class="btn btn-success" type="submit" name="submit"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;Add</button>
            <button type="reset" class="btn btn-success"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>&nbsp;Reset</button>
          </div>
        </form>
      </div>
    </section>
  </div>
  <?php include_once('includes/footer.php'); ?>
</div>
<!-- ./wrapper -->
<?php include_once('includes/alljs.php'); ?>
<script src="<?php echo BASE_URL; ?>/plugins/iCheck/icheck.min.js"></script>
<script type="text/javascript">
jQuery(function()  
{ 
  jQuery('body').delegate('.remove','click',function()  
	{  
	  jQuery(this).parent().parent().remove();  
	});
	
   jQuery('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-red',
      radioClass: 'iradio_flat-red'
    });
	
	jQuery('input[type="checkbox"].flat-orange, input[type="radio"].flat-orange').iCheck({
      checkboxClass: 'icheckbox_flat-orange',
      radioClass: 'iradio_flat-orange'
    });	
	
	jQuery('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });	
	
	jQuery('input[type="checkbox"].flat-yellow, input[type="radio"].flat-yellow').iCheck({
      checkboxClass: 'icheckbox_flat-yellow',
      radioClass: 'iradio_flat-yellow'
    });	
	
	jQuery('input[type="checkbox"].flat-aero, input[type="radio"].flat-aero').iCheck({
      checkboxClass: 'icheckbox_flat-aero',
      radioClass: 'iradio_flat-aero'
    });		
	
}); 

function addAssesment_month(){
    var today = new Date(); //Get today's date
    var lastDate = new Date(today.getFullYear(), today.getMonth() + 1, 0); 
    jQuery('input').filter('.assesment_month').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd',
	  startDate: '-2m',
	  endDate: lastDate,
	  startView: "year", 
      minViewMode: "months"
    });
}

function addMeetingdate(){
    var today = new Date(); //Get today's date
    var lastDate = new Date(today.getFullYear(), today.getMonth() + 1, 0); 
    jQuery('input').filter('.meeting_date').datepicker({
      format: 'yyyy-mm-dd',
	  startDate: '-2m',
	  endDate: '+0d',
    });
}

function addAttritiondate(){
    var today = new Date(); //Get today's date
    var lastDate = new Date(today.getFullYear(), today.getMonth() + 1, 0); 
    jQuery('input').filter('.attrition_date').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd',
	  startDate: '+1d',
	  endDate: '+15d'
   });
}

function getvaloneonone(sel)
{
    var numberIncr = jQuery('#starting_emp').val();
	if(sel.value==1){
	jQuery("#one_on_one_ass_form_"+numberIncr+"").slideDown("slow");
	jQuery("#one_on_one_ass_hr_"+numberIncr+"").slideDown("slow");
	} else {
	jQuery("#one_on_one_ass_form_"+numberIncr+"").slideUp("slow");
	jQuery("#one_on_one_ass_hr_"+numberIncr+"").slideUp("slow");
	}
}

function getvalbehavior_motivation(sel)
{
  var numberIncr = jQuery('#starting_emp').val();
	if(sel.value==1){
	jQuery("#behaviorial_details_form_"+numberIncr+"").slideDown("slow");
	jQuery("#behaviorial_details_hr_"+numberIncr+"").slideDown("slow");
	} else {
	jQuery("#behaviorial_details_form_"+numberIncr+"").slideUp("slow");
	jQuery("#behaviorial_details_hr_"+numberIncr+"").slideUp("slow");
	}
}

function getvalemployeeID(sel) 
{
   emp_id = sel.value;
   jQuery('#employee_last_pie_records').hide();
   jQuery("#employee_lastmonth_pie_records").hide();
   jQuery("#employee_last2lastmonth_pie_records").hide();
   jQuery.ajax({
				type: 'post',
				data: 'manager_id='+<?php echo $_SESSION['userid']; ?>+'&department_id='+<?php echo $_SESSION['department']; ?>+'&bu_id='+<?php echo $_SESSION['business_unit']; ?>+'&emp_id='+emp_id,
				url: '<?php echo BASE_URL; ?>/inc/data_graph_employee.php',
				success: function(data) {
				jQuery('#employee_last_pie_records').slideToggle();
				//jQuery("#employee_current_pie_records").fadeIn();
				//jQuery("#employee_last2lastmonth_pie_records").fadeIn();
				//alert(data);
                var arr = data.split('::::');
				//alert(one);
				if(arr[0] > 0) {
				jQuery("#employee_lastmonth_pie_records").fadeIn(1000);
				
				if (arr[0]==1) {
				   title = 'High Risk';
				   color = '#dd4b39';
				} else if(arr[0]==2) {
				    title = 'Medium Risk';
				   color = '#f39c12';
				} else {
				     title = 'Low Risk';
				   color = '#00a65a';
				}
				  //alert(title);
				 $('.second.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('strong').html(title+'<br /> Score: '+arr[3]);
				  });
				} else {
				   jQuery("#employee_lastmonth_pie_records").fadeIn(1000);
				  // jQuery('#secondcircle').html('Record Not Found');
				   $('.second.circle').circleProgress({
					 value: 1,
					 fill: {color:'#D3D3D3'},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('strong').html('Record Not <br /> Found');
				  });
				 }
				
				if(arr[1] > 0) {
				jQuery("#employee_last2lastmonth_pie_records").fadeIn(1000);
				
				if (arr[1]==1) {
				   titlesecond = 'High Risk';
				   color = '#dd4b39';
				} else if(arr[1]==2) {
				    titlesecond = 'Medium Risk';
				   color = '#f39c12';
				} else {
				     titlesecond = 'Low Risk';
				   color = '#00a65a';
				}
				//alert(titlesecond);
			   $('.third.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('strong').html(titlesecond+'<br /> Score: '+arr[4]);
				  });
			 }	 else {
			       jQuery("#employee_last2lastmonth_pie_records").fadeIn(1000);
				   $('.third.circle').circleProgress({
					 value: 1,
					 fill: {color:'#D3D3D3'},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('strong').html('Record Not <br /> Found');
				  });
				 }
				
				if (arr[2]!='') {
				    jQuery('#employeename_display').html('For : ' + arr[2]);
				} 
			}
  }); 
}

	jQuery('.performance').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = this.value;
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").show();
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.leave_r').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
			var performance = $('#performance:checked').val();
            var leave_r = this.value;
			//var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
				
    });
	
	jQuery('.external_interviews').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = this.value;
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.personal_effectiveness').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = this.value;
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.career_growth').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = this.value;
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.skill_set').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = this.value;
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = $('#behavior_motivation:checked').val();
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.one_on_one_ass').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = this.value;
			var behavior_motivation = $('#behavior_motivation:checked').val();
			if(one_on_one_ass==1){
			    jQuery("#additional_id").show();
				jQuery("#one_on_one_ass_form").slideDown("slow");
				} else {
				jQuery("#additional_id").hide();
				jQuery("#one_on_one_ass_form").slideUp("slow");
			}
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			jQuery("#employee_current_pie_records").fadeIn(1000);
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });
	
	jQuery('.behavior_motivation').on('ifClicked', function(event){
	        //alert("You clicked " + this.value);
            var performance = $('#performance:checked').val();
			var leave_r = $('#leave_r:checked').val();
			var external_interviews = $('#external_interviews:checked').val();
			var personal_effectiveness = $('#personal_effectiveness:checked').val();
			var career_growth = $('#career_growth:checked').val();
			var skill_set = $('#skill_set:checked').val();
			var one_on_one_ass = $('#one_on_one_ass:checked').val();
			var behavior_motivation = this.value;
			var totalincome = parseInt(performance) + parseInt(leave_r)+ parseInt(external_interviews)+ parseInt(personal_effectiveness)+ parseInt(career_growth)+ parseInt(skill_set)+ parseInt(one_on_one_ass)+ parseInt(behavior_motivation);
			if(behavior_motivation==1){
			    jQuery("#additional_id_new").show();
				jQuery("#behaviorial_details_form").slideDown("slow");
				jQuery("#behaviorial_details_hr").slideDown("slow");
				} else {
				jQuery("#additional_id_new").hide();
				jQuery("#behaviorial_details_form").slideUp("slow");
				jQuery("#behaviorial_details_hr").slideUp("slow");
		        }
			jQuery("#employee_current_pie_records").show();
           //alert(totalincome);
			if (totalincome <= 23) {
				   titlefirst = 'High Risk';
				   color = '#dd4b39';
				} else if(totalincome >= 24 && totalincome  <= 29) {
				    titlefirst = 'Medium Risk';
				   color = '#f39c12';
				} else if (totalincome >= 30) {
				     titlefirst = 'Low Risk';
				   color = '#00a65a';
				}
				
				$('.first.circle').circleProgress({
					value: 1,
					 fill: {color:color},
					 size: 180
					}).on('circle-animation-progress', function(event, progress) {
					$(this).find('div#firstcircle').html(titlefirst+'<br /> Score: '+totalincome);
				  });
    });



</script>
</body>
</html>
