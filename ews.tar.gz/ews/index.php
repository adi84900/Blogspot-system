<?php
ob_start();
session_start();
error_reporting(0);
/*print_r($_POST);
print_r($_SESSION);
print_r($_COOKIE);*/
include('config/config.php');
include('config/php_mysql_class.php');
include('config/function.php');
if(isset($_REQUEST['submit_login']))
{
	    $username=$_POST['username'];
	    $password=$_POST['password'];
		$auth = authUser($username, $password);
		if ($_SESSION['username']!='' && $_SESSION['user_type']!='')
		{
		  if(!empty($_POST["remember"])) {
				setcookie ("emp_username",$_POST["username"],time()+ (10 * 365 * 24 * 60 * 60));
				setcookie ("emp_password",$_POST["password"],time()+ (10 * 365 * 24 * 60 * 60));
			} else {
				if(isset($_COOKIE["emp_username"])) {
					setcookie ("emp_username","");
				}
				if(isset($_COOKIE["emp_password"])) {
					setcookie ("emp_password","");
				}
			}
		  header( "location: dashboard.php" );
		}
		else
		{
		// header( "location: index.php" );
		$_SESSION['error_login']="Invalid username or password or may be account expires.";
		}
}    
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Sign In | Retention</title>
<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.6 -->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/dist/css/AdminLTE.min.css">
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/plugins/iCheck/square/green.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
<script type="text/javascript"  src="<?php echo BASE_URL; ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>/plugins/jquerycycle/jquery.cycle.all.js"></script>
<script>
jQuery(document).ready(function() {
	$('#slideshow').cycle({
	speed: 1000,
	timeout:500,
	fx:'scrollLeft',
	next:'#next2',
    prev:'#prev2'
	});
});
</script>
<script src="<?php echo BASE_URL; ?>/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-green',
      radioClass: 'iradio_square-green',
      increaseArea: '20%' // optional
    });
  });
</script>
<script src="<?php echo BASE_URL; ?>/bootstrap/js/jquery.validate.js"></script>
<script>
jQuery(document).ready(function(){
		  jQuery("#loginform").validate({
			rules: {     
				username: {required: true},
				password: {required: true}
			},
			messages: {
				username: {
                required:"Please Enter Username"
                },
				password: {
                required:"Please Enter Password"
                }
			},
		});

});
</script>
<style>
.error_validation {
color:red;
font-weight:normal;
font-size:12px;
}

#slideshow, img.bgM {
  min-height: 100%;
  min-width: 1024px;
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index:-9999;
}

.content {
    padding-bottom: 50px;
}
.main-footer-new {
    background: #00a65a;
    padding: 15px;
	color:#ffffff;
    height: auto;
    margin-left: @left-side-width;
	bottom: 0px;
    position: fixed;
    width: 100%;
    &.full-width {
        margin-left: 0;
    }
}

.main-footer-new a  {
	color:#ffffff;
}

.main-footer-new a:hover {
	color:#f39c12;
	text-decoration:underline;
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="background-color: #00a65a; height:85px;">
  <div class="container"> <a class="navbar-brand" href="<?php echo BASE_URL; ?>/index.php"><img src="<?php echo BASE_URL; ?>/dist/img/caveat.png" /></a> </div>
</nav>
<div id="slideshow">
 <img src="<?php echo BASE_URL; ?>/dist/img/bg.jpg" class="bgM"/> <!--<img src="<?php echo BASE_URL; ?>/dist/img/2.jpg" class="bgM"/> <img src="<?php echo BASE_URL; ?>/dist/img/3.jpg" class="bgM"/> <img src="<?php echo BASE_URL; ?>/dist/img/4.jpg" class="bgM"/>-->  </div>
<div id="row">
  <div class="login-box">
    <div class="login-box-body">
      <p class="login-box-msg">Sign in to start your session</p>
      <?php
				if(isset($_SESSION['error_login']))
				{
				echo '<p style="color:#ff0000;" align="center">'.$_SESSION['error_login'].'</p>';
				unset($_SESSION['error_login']);				
				}
				else
				{
				//echo '<p style="color:#ff0000;" align="center">Enter your login credentials.</p>';
				}
				?>
      <form method="post" action="" id="loginform" name="loginform">
        <div class="form-group has-feedback">
          <input type="text" class="form-control" placeholder="Enter Username" name="username" value="<?php if(isset($_COOKIE["emp_username"])) { echo $_COOKIE["emp_username"]; } ?>">
          <span class="glyphicon glyphicon-envelope form-control-feedback"></span> </div>
        <div class="form-group has-feedback">
          <input type="password" class="form-control" placeholder="Enter Password" name="password" value="<?php if(isset($_COOKIE["emp_password"])) { echo $_COOKIE["emp_password"]; } ?>">
          <span class="glyphicon glyphicon-lock form-control-feedback"></span> </div>
        <div class="row">
          <div class="col-xs-8">
            <div class="checkbox icheck">
              <label>
              <input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["emp_username"])) { ?> checked <?php } ?>>
              Remember Me </label>
            </div>
          </div>
          <div class="col-xs-4">
            <input type="submit" value="Sign In" name="submit_login" class="btn btn-primary btn-block btn-flat" style="background:#00a65a;"/>
          </div>
          <!-- /.col -->
        </div>
      </form>
    </div>
  </div>
</div>
<footer class="main-footer-new">
  <div class="pull-right hidden-xs">Retention 3.0.0 </div>
  Copyright &copy; <?php echo date("Y"); ?> <strong><a href="http://www.quatrro.com/" target="_blank">Quatrro Global Services.</a></strong> All rights reserved. </footer>
</body>
</html>
