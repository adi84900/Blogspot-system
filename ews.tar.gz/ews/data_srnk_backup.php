<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysql_connect($servername, $username, $password);
mysql_select_db("db_ews");
$sql="select * from lms_JAGAUR_Sync where ou!=''";
$sql_query=mysql_query($sql) or die(mysql_error());
 $countinsert=0;
  $countupdate=0;
while($row = mysql_fetch_array($sql_query))
{
  $employee_st=$row['EmployeeStatus'];
  if($employee_st=="ACTIVE")
  {
     $status_emp=0;
  }
  else
  {
  $status_emp=1;
  }
  
  $sqlselect="select user_id,`first_name`,`last_name`,`email_id` from users where username='".$row['employee_code']."'";
 // echo $sqlselect;
  $resultcheck	=	mysql_query($sqlselect) ;
  $numrows		=	mysql_num_rows($resultcheck);
 
  //echo $numrows;
  if($numrows < 1)
  {
    //echo "hello";
  $sql="INSERT INTO `users` (`user_type`, `first_name`, `last_name`, `username`, `password`, `email_id`, `business_unit`, `band`, `grade`, `departmentcode`, `department`, `manager_name`, `manager_id`, `managersemail`, `phone`, `city`, `state`, `country`, `first_access`, `last_access`, `last_login`, `current_login`, `last_ip`, `created_by`, `created_on`, `modified_by`, `modified_on`, `emp_type`, `doj`, `status`, `DateOfSeparation`, `attempt`) VALUES ('', '$row[FirstName]', '$row[LastName]', '$row[employee_code]', '1a1dc91c907325c69271ddf0c944bc72', '$row[EMail]', '$row[ou]', '$row[GradeSet]', '$row[Grade]', '$row[DepartmentCode]', '$row[Department]', '$row[SupervisorName]', '$row[managerid]', '$row[managersemail]', '$row[Mobile]', '$row[WorkLocation]', '', '', '', '', '', '', '', '', '', '', '', '$row[EmployeeType]', '$row[doj]', '$status_emp', '$row[DateOfSeparation]', '')";
   mysql_query( $sql) or die(mysql_error());
    $countinsert++;
 }
 else
 {
 
     $sql_update="update `users` SET `email_id`='$row[EMail]', `business_unit`='$row[ou]', `band`='$row[GradeSet]', `grade`='$row[Grade]', `departmentcode`='$row[DepartmentCode]', `department`='$row[Department]', `manager_name`='$row[SupervisorName]', `manager_id`='$row[managerid]', `managersemail`='$row[managersemail]', `phone`='$row[Mobile]', `city`='$row[WorkLocation]', `emp_type`='$row[EmployeeType]', `doj`='$row[doj]', `status`='$status_emp', `DateOfSeparation`='$row[DateOfSeparation]' where username='$row[employee_code]'";
	 
   mysql_query( $sql_update) or die(mysql_error());
   
	$countupdate++;
 }
 
}

echo "Number of recod inserted ".$countinsert;
echo '<br>';
echo "Number of recod updated ".$countupdate;
?>