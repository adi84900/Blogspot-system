<?php
ob_start();
session_start();
if(!$_SESSION['userid']){
   header("location:index.php");
   die;
}
include_once('config/config.php');
include_once('config/php_mysql_class.php');
include_once('config/function.php');
$mysql=new mysql();
/*echo '<pre>';
print_r($_SESSION);
echo '</pre>';*/
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>My Dashboard | Retention</title>
<?php include_once('includes/allcss.php'); ?>
</head>
<body class="hold-transition skin-green-light sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php
			 if($_SESSION['user_type']==1) {
				include('includes/leftside_admin.php');
			 } elseif($_SESSION['user_type']==3) {
				include('includes/leftside_hr.php');
			 } elseif($_SESSION['user_type']==4) {
			  include('includes/leftside_amdm.php');
		  } elseif($_SESSION['user_type']==5) {
			   include('includes/leftside_manager.php');
		  } 
	   ?>
  <?php //include_once('includes/leftside.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>My Dashboard</h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <?php
			 if($_SESSION['user_type']==1) {
				include('includes/dashboard_admin.php');
			 } elseif($_SESSION['user_type']==3) {
				include('includes/dashboard_hr.php');
			 } elseif($_SESSION['user_type']==4) {
			  include('includes/dashboard_amdm.php');
		  } elseif($_SESSION['user_type']==5) {
			   include('includes/dashboard_manager.php');
		  } 
	   ?>
    </section>
    <!-- /.content -->
  </div>
  <?php include_once('includes/footer.php'); ?>
</div>
<!-- ./wrapper -->
<?php 
			include_once('includes/alljs.php'); 
			 if($_SESSION['user_type']==1){ 
			  include('includes/dashboard_admin.php');
			 } elseif($_SESSION['user_type']==3) {
			include('includes/graph_hr.php');
			 } elseif($_SESSION['user_type']==4) { 
			include('includes/graph_amdm.php');
			 } elseif($_SESSION['user_type']==5) { 
			include('includes/graph_manager.php');
			 } 
  ?>
</body>
</html>
