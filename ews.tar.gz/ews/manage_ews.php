<?php
ob_start();
session_start();
if(!$_SESSION['userid']){
   header("location:index.php");
   die;
}
include_once('config/config.php');
include_once('config/php_mysql_class.php');
include_once('config/function.php');

function ExportCSVFile($records) {
	// create a file pointer connected to the output stream
	$fh = fopen( 'php://output', 'w' );
	$heading = false;
		if(!empty($records))
		  foreach($records as $row) {
			if(!$heading) {
			  // output the column headings
			  fputcsv($fh, array_keys($row));
			  $heading = true;
			}
			// loop over the rows, outputting them
			 fputcsv($fh, array_values($row));
			 
		  }
		  fclose($fh);
}
function ExportFile($records) {
	$heading = false;
	if(!empty($records))
	  foreach($records as $row) {
		if(!$heading) {
		  // display field/column names as a first row
		  echo implode("\t", array_keys($row)) . "\n";
		  $heading = true;
		}
		echo implode("\t", array_values($row)) . "\n";
	  }
	exit;
}
//print_r($_SESSION);
//$page = (int) $_GET['page'];
$page = isset($_GET['page']) ? mysql_real_escape_string($_GET['page']) : 0;
if ($page < 1) $page = 1;
$numberOfPages = 5;
$resultsPerPage = 30;
$startResults = ($page - 1) * $resultsPerPage;
$mysql = new mysql();
 $user_name=$_SESSION['userid'];
 $userid= $_SESSION['userid'];
 $user_types=$_SESSION['user_type'];
 //echo $user_types;
 
 if(isset($_REQUEST['filter_submit']))
 {
  $bu_unit=$_SESSION['business_unit'];
  /*$department=$_SESSION['department'];*/
  $manager_name=$_SESSION['manager_id'];
  $supervisor_name=$_SESSION['userid'];
  $emp_id=$_GET['emp_id'];
  $assesment_month=$_GET['assesment_month'];
  $fromdate_filter=$_GET['fromdate_filter'];
  $todate_filter=$_GET['todate_filter'];
  $ews_status=$_GET['ews_status'];
  if($emp_id==0)
  {
  $emp_id='';
  }
  
  if($ews_status==0)
  {
  $ews_status='';
  }
  
  if ($assesment_month == 0) {
        $assesment_month = '';
    } else {
        $assesment_month = date("Y-m", strtotime($assesment_month));
    }
  
  if($fromdate_filter!='' && $todate_filter!='')
  {
   $fromdate_filter= date("Y-m-d h:m:s", strtotime($fromdate_filter));
   $todate_filter= date("Y-m-d  h:m:s", strtotime($todate_filter));
  // $condition = "(`business_unit` LIKE '%$bu_unit%' AND `department` LIKE '%$department%'  AND `manager_detail` LIKE '%$manager_name%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%' AND `assesment_month` LIKE '%$assesment_month%' AND `status` LIKE '%$ews_status%') AND created_date between '$fromdate_filter' and '$todate_filter'";
   $condition = "(`business_unit` LIKE '%$bu_unit%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%' AND `assesment_month` LIKE '%$assesment_month%' AND `status` LIKE '%$ews_status%') AND created_date between '$fromdate_filter' and '$todate_filter'";
  }
  else
  {
  //$condition = "`business_unit` LIKE '%$bu_unit%' AND `department` LIKE '%$department%'  AND `manager_detail` LIKE '%$manager_name%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%' AND `assesment_month` LIKE '%$assesment_month%' AND `status` LIKE '%$ews_status%'";
  $condition = "`business_unit` LIKE '%$bu_unit%' AND `supervisor_detail` LIKE '%$supervisor_name%' AND `emp_id` LIKE '%$emp_id%' AND `assesment_month` LIKE '%$assesment_month%' AND `status` LIKE '%$ews_status%'";
  }
   if($user_types==1 || $user_types==2 || $user_types==3 )
		 {
		  $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition'=> $condition,'order'=>'created_date DESC'));
		  $totalPages = ceil($numberOfRows / $resultsPerPage);
          $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
		   $users_ews_export=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition ,'order'=>'created_date DESC'));
		 }
		else
		{
		 $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition'=> $condition,'order'=>'created_date DESC'));
		 $totalPages = ceil($numberOfRows / $resultsPerPage);
		 $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
		 $users_ews_export= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=> $condition,'order'=>'created_date DESC'));
		}
 }
 else
 {
		 if($user_types==1 || $user_types==2 || $user_types==3)
		 {
		 $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition' =>'1=1','order'=>'created_date DESC'));
		 $totalPages = ceil($numberOfRows / $resultsPerPage);
		 $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'1=1' ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
		 $users_ews_export=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'1=1' ,'order'=>'created_date DESC'));
		 }
		 else if($user_types==4)
		 {
		 $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition' =>'supervisor_detail='.$userid,'order'=>'created_date DESC'));
		 $totalPages = ceil($numberOfRows / $resultsPerPage);
		 $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'supervisor_detail='.$userid ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
		 $users_ews_export= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'supervisor_detail='.$userid ,'order'=>'created_date DESC'));
		 } else if($user_types==5)
		 {
		 $numberOfRows  = $mysql->countRows(array('table' => 'ews_detail', 'fields' => '*', 'condition' =>'supervisor_detail='.$userid,'order'=>'created_date DESC'));
		 $totalPages = ceil($numberOfRows / $resultsPerPage);
		 $users_ews=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'supervisor_detail='.$userid ,'order'=>'created_date DESC','limit' =>$resultsPerPage,'offset' =>$startResults));
		 $users_ews_export= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'supervisor_detail='.$userid ,'order'=>'created_date DESC'));
		 } 
		
 }
 
 
 if(isset($_POST["ExportType"]))
{

              $data = array();
		      foreach ($users_ews_export  as $values_export) {
			                            $bu_ids= $values_export['ews_detail']['business_unit'];
										$department= $values_export['ews_detail']['department'];
										$business_name=$mysql->get('business_name','business_name','business_code='.$bu_ids);
										$department=$mysql->get('department_master','department_name','id='.$department);
										$emp_id= $values_export['ews_detail']['emp_id'];
										$id= $values_export['ews_detail']['id'];
										$supervisor_detail= $values_export['ews_detail']['supervisor_detail'];
										$manager_detail= $values_export['ews_detail']['manager_detail'];
										$criticality_check= $values_export['ews_detail']['criticality_check'];
										if($criticality_check == 1)
										{
										 $criticality="High";
										}
										else if($criticality_check == 2)
										{
										 $criticality="Medium";
										}
										else if($criticality_check == 3)
										{
										 $criticality="Low";
										}
										
										$supervisor_comment= $values_export['ews_detail']['comment'];
										if($supervisor_comment!='') {
										$comment_new=$supervisor_comment;
										}else{
										 $comment_new='N/A';
										}
										
										$supervisor_action_plan= $values_export['ews_detail']['action_plan'];
										if($supervisor_action_plan!='') {
										$action_plan_new=$supervisor_action_plan;
										}else{
										 $action_plan_new='N/A';
										}
									
									$events_detail_total=$values_export['ews_detail']['one_on_one_ass']+$values_export['ews_detail']['performance']+$values_export['ews_detail']['leave_r']+$values_export['ews_detail']['external_interviews']+$values_export['ews_detail']['behavior_motivation']+$values_export['ews_detail']['personal_effectiveness']+$values_export['ews_detail']['career_growth']+$values_export['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$risk="High";
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$risk="Medium";
									}
									else if($events_detail_total >= 30)
									{
									$risk="Low";
									}
									
								$first_name=$mysql->get('users','first_name','user_id='.$emp_id);
								$last_name=$mysql->get('users','last_name','user_id='.$emp_id);
								$username=$mysql->get('users','username','user_id='.$emp_id);
								
								$filledby_fname=$mysql->get('users','first_name','user_id='.$supervisor_detail);
					            $filledby_lname=$mysql->get('users','last_name','user_id='.$supervisor_detail);
								$filledby_id=$mysql->get('users','username','user_id='.$supervisor_detail);
								
								 $status=$mysql->get('users','status','user_id='.$emp_id);
													 if($status==0)
													 {
													   $emp_status = 'Active';
													 }
													 else
													 {
													   $emp_status = 'Resigned';
													 }
								
			  
			  $data[] = array('Employee Details' => $first_name.' '.$last_name.' ('.$username.')', 'Filled By' => $filledby_fname.' '.$filledby_lname.' ('.$filledby_id.')', 'Month Of Assesment' => date('F Y', strtotime($values_export['ews_detail']['assesment_month'])), 'Meet up Date' => date('d F Y', strtotime($values_export['ews_detail']['meeting_date'])),'Created Date' => date('d F Y', strtotime($values_export['ews_detail']['created_date'])),'Criticality' => $criticality,'Risk' => $risk,'Emp Status' => $emp_status,'Performance' => $values_export['ews_detail']['performance'],'Leave' => $values_export['ews_detail']['leave_r'],'External Interviews' => $values_export['ews_detail']['external_interviews'],'Behavior/ Motivation' => $values_export['ews_detail']['behavior_motivation'],'Personal Effectiveness' => $values_export['ews_detail']['personal_effectiveness'],'Career Growth' => $values_export['ews_detail']['career_growth'],'Skill Set' => $values_export['ews_detail']['skill_set'],'1 to 1 Assessment' => $values_export['ews_detail']['one_on_one_ass'],'Comment' => $comment_new,'Action Plan' => $action_plan_new);
			}
			
			

	switch($_POST["ExportType"])
    {
        case "export-to-excel" :
            // Submission from
			$filename = "export-ews-".date('d-F-Y').".xls";		 
            header("Content-Type: application/vnd.ms-excel");
			header("Content-Disposition: attachment; filename=\"$filename\"");
			ExportFile($data);
			//$_POST["ExportType"] = '';
            exit();
		case "export-to-csv" :
            // Submission from
			$filename = "export-ews-".date('d-F-Y').".csv";		 
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Content-type: text/csv");
			header("Content-Disposition: attachment; filename=\"$filename\"");
			header("Expires: 0");
			ExportCSVFile($data);
			//$_POST["ExportType"] = '';
            exit();
        default :
            die("Unknown action : ".$_POST["action"]);
            break;
    }
}			
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>View Retention | Retention</title>
<?php include_once('includes/allcss.php'); ?>
</head>
<body class="hold-transition skin-green-light sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php
			 if($_SESSION['user_type']==1) {
				include('includes/leftside_admin.php');
			 } elseif($_SESSION['user_type']==3) {
				include('includes/leftside_hr.php');
			 } elseif($_SESSION['user_type']==4) {
			  include('includes/leftside_amdm.php');
		  } elseif($_SESSION['user_type']==5) {
			   include('includes/leftside_manager.php');
		  } 
	   ?>
  <?php //include_once('includes/leftside.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> View Retention </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> My Dashboard</a></li>
        <li class="active">View Retention</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            <div class="box-body">
              <div class="row">
                <?php
				 if($_SESSION['user_type']==1 || $_SESSION['user_type']==2 || $_SESSION['user_type']==3)
				 {
				 ?>
                <form action="" method="get" name="userews">
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>Business Unit<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="business_unit" onChange="getdepartment(this.value)" class="form-control select2" id="business_unit">
                        <option value="" selected="selected">Select BU</option>
                        <?php 
								 $show_bu=  $mysql->select(array('table'=>'business_name','fields'=>'*'));
								  foreach($show_bu as $key=>$value)
									 {
								 ?>
                        <option value="<?php echo $value['business_name']['business_code']; ?>" <?php if(isset($_GET['business_unit'])){if($_GET['business_unit']==$value['business_name']['business_code']) echo "selected";}?>> <?php echo $value['business_name']['business_name']; ?> </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="department_div">
                      <label>Department<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="department" class="form-control select2" id="department">
                        <option value="" selected="selected">Select Department</option>
                        <?php 
				 $bu_id=$_GET['business_unit'];
				 $department=  $mysql->select(array('table'=>'department_master','fields'=>'*','condition'=>'INSTR (business_unit, '.$bu_id.')','order'=>'department_name'));
				  foreach($department as $key=>$value)
					 {
				 ?>
                        <option value="<?php echo $value['department_master']['id']; ?>" <?php if(isset($_GET['department'])){if($_GET['department']==$value['department_master']['id']) echo "selected";}?>> <?php echo $value['department_master']['department_name']."(".$value['department_master']['department_code'].")"; ?> </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="manager_div">
                      <label>Manager Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="manager_detail" class="form-control select2" id="manager_detail">
                        <option value="" selected="selected">Select Manager</option>
                        <?php 
				 $bu_id_new=$_GET['business_unit'];
				 $department_id_new=$_GET['department'];
				 $manager_detail_new=$_GET['manager_detail'];
				 $manager_name_new=  $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and department='.$department_id_new.' and user_type in(3,4) and status=0','order'=>'first_name'));
				  foreach($manager_name_new as $key=>$valueuser)
					 {
				 ?>
                        <option value="<?php echo $valueuser['users']['user_id']; ?>" <?php if(isset($_GET['manager_detail'])){if($_GET['manager_detail']==$valueuser['users']['user_id']) echo "selected";}?>> <?php echo $valueuser['users']['first_name'].' '. $valueuser['users']['last_name']."(".$valueuser['users']['username'].")"; ?> </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="am_dm_div">
                      <label>AM/DM Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="supervisor_detail" class="form-control select2" id="supervisor_detail">
                        <option value="" selected="selected">Select AM/DM</option>
                        <?php 
				 $bu_id_new=$_GET['business_unit'];
				 $department_id_new=$_GET['department'];
				 $manager_detail_new=$_GET['manager_detail'];
				 $amdm_detail_new=$_GET['supervisor_detail'];
				 $manager_ids=$mysql->get('users','username','user_id='.$manager_detail_new);
				 $supervisor_name_new= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and department='.$department_id_new.' and manager_id LIKE "%'.$manager_ids.'%" and user_type!=6 and status=0','order'=>'first_name'));
				  foreach($supervisor_name_new as $key=>$valuesupervisor)
					 {
				 ?>
                        <option value="<?php echo $valuesupervisor['users']['user_id']; ?>" <?php if(isset($_GET['supervisor_detail'])){if($_GET['supervisor_detail']==$valuesupervisor['users']['user_id']) echo "selected";}?>> <?php echo $valuesupervisor['users']['first_name'].' '. $valuesupervisor['users']['last_name']."(".$valuesupervisor['users']['username'].")"; ?> </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group" id="employee_div">
                      <label>Employee Name<span style="color:#FF0000; font-weight:bold"><sup>*</sup></span></label>
                      <select name="emp_id" class="form-control select2" id="emp_id">
                        <option value="" selected="selected">Select Employee</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>From</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="from" type="text" name="fromdate_filter">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="width:13%;">
                    <div class="form-group">
                      <label>To</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="to" type="text" name="todate_filter">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-1" style="padding-top:25px;">
                    <div class="form-group">
                      <button class="btn btn-success" type="submit" name="filter_submit"><span class="fa fa-search" aria-hidden="true"></span> Go</button>
                    </div>
                  </div>
                </form>
                <?php } else { ?>
                <form action="" method="get" name="userews">
                  <div class="col-md-2">
                    <div class="form-group" id="employee_div">
                      <label>Employee Name</label>
                      <select name="emp_id" class="form-control select2" id="emp_id">
                        <option value="" selected="selected">All</option>
						<?php 
				 $bu_id_new=$_SESSION['business_unit'];
				 $department_id_new=$_SESSION['department'];
				 $manager_detail_new=$_SESSION['manager_id'];
				 $amdm_detail_new=$_SESSION['userid'];
				 $manager_ids=$mysql->get('users','username','user_id='.$amdm_detail_new);
				 $supervisor_name_new= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id_new.' and manager_id LIKE "%'.$manager_ids.'%" and user_type=6 and status=0','order'=>'first_name'));
				  foreach($supervisor_name_new as $key=>$valuesupervisor)
					 {
				 ?>
                        <option value="<?php echo $valuesupervisor['users']['user_id']; ?>" <?php if(isset($_GET['emp_id'])){if($_GET['emp_id']==$valuesupervisor['users']['user_id']) echo "selected";}?>> <?php echo $valuesupervisor['users']['first_name'].' '. $valuesupervisor['users']['last_name']."(".$valuesupervisor['users']['username'].")"; ?> </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
				  <div class="col-md-2">
                    <div class="form-group" id="employee_div">
                      <label>Risk</label>
                      <select name="ews_status" class="form-control select2" id="ews_status">
                        <option value="" <?php if(isset($_GET['ews_status'])){if($_GET['ews_status']=='') echo "selected";}?>>All</option>
						<option value="1" <?php if(isset($_GET['ews_status'])){if($_GET['ews_status']=='1') echo "selected";}?>>High</option>
						<option value="2" <?php if(isset($_GET['ews_status'])){if($_GET['ews_status']=='2') echo "selected";}?>>Medium</option>
						<option value="3" <?php if(isset($_GET['ews_status'])){if($_GET['ews_status']=='3') echo "selected";}?>>Low</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <label>Month Of Assesment</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="assesment_month_search" type="text" name="assesment_month" value="<?php if(isset($_GET['assesment_month'])){ echo $_GET['assesment_month']; }?>">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <label>From</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="fromdate_filter" type="text" name="fromdate_filter" value="<?php if(isset($_GET['fromdate_filter'])){ echo $_GET['fromdate_filter']; }?>">
                      </div>
                    </div>
                  </div>
				  <div class="col-md-2">
                    <div class="form-group">
                      <label>To</label>
                      <div class="input-group date">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" id="todate_filter" type="text" name="todate_filter" value="<?php if(isset($_GET['todate_filter'])){ echo $_GET['todate_filter']; }?>">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-1" style="padding-top:25px;">
                    <div class="form-group">
                      <button class="btn btn-success" type="submit" name="filter_submit"><span class="fa fa-search" aria-hidden="true"></span> Go</button>
                    </div>
                  </div>
				  </form>
				  <?php if(!empty($users_ews)) { ?> 
				  <form action="" method="post" id="export-form">
			       <input type="hidden" value='' id='hidden-type' name='ExportType'/>
				   <div class="col-md-1" style="padding-top:25px;  padding-left: 0px;">
                    <div class="form-group">
					  <button class="btn btn-success dropdown-toggle" data-toggle="dropdown" name="export_to_excel"><span class="glyphicon glyphicon-export" aria-hidden="true"></span> Export</button>
					  <ul class="dropdown-menu" role="menu" id="export-menu">
						    <li id="export-to-excel"><a href="javascript:void(0);">Export to excel</a></li>
							<li id="export-to-csv"><a href="javascript:void(0);">Export to csv</a></li>
						  </ul> 	  
                    </div>
                  </div>
                </form>
				  <?php } ?>
                <?php } ?>
              </div>
            </div>
          </div>
          <div class="box box-success">
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody>
                  <tr>
                    <th>Employee Details</th>
                    <th>Filled By</th>
					<th>Month Of Assesment</th>
                    <th>Meet up Date</th>
                    <th>Created Date</th>
					<th>Criticality</th>
                    <th>Risk</th>
                    <th>Action</th>
                  </tr>
				  <?php if(empty($users_ews)) {
				   echo '<tr>
				  <td colspan="7">No result found.</td>
                  </tr>';
				   }  else  {  
				  foreach($users_ews as $key=>$value_ews)
									 {
										$bu_ids= $value_ews['ews_detail']['business_unit'];
										$department= $value_ews['ews_detail']['department'];
										$business_name=$mysql->get('business_name','business_name','business_code='.$bu_ids);
										$department=$mysql->get('department_master','department_name','id='.$department);
										$emp_id= $value_ews['ews_detail']['emp_id'];
										$id= $value_ews['ews_detail']['id'];
										$supervisor_detail= $value_ews['ews_detail']['supervisor_detail'];
										$manager_detail= $value_ews['ews_detail']['manager_detail'];
										$criticality_check= $value_ews['ews_detail']['criticality_check'];
										if($criticality_check == 1)
										{
										 $criticality="<span class='label label-danger'>High</span>";
										}
										else if($criticality_check == 2)
										{
										 $criticality="<span class='label label-warning'>Medium</span>";
										}
										else if($criticality_check == 3)
										{
										 $criticality="<span class='label label-success'>Low</span>";
										}
									
									$events_detail_total=$value_ews['ews_detail']['one_on_one_ass']+$value_ews['ews_detail']['performance']+$value_ews['ews_detail']['leave_r']+$value_ews['ews_detail']['external_interviews']+$value_ews['ews_detail']['behavior_motivation']+$value_ews['ews_detail']['personal_effectiveness']+$value_ews['ews_detail']['career_growth']+$value_ews['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$risk="<span class='label label-danger'>High</span>";
									$model_class="modal-danger";
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$risk="<span class='label label-warning'>Medium</span>";
									$model_class="modal-warning";
									}
									else if($events_detail_total >= 30)
									{
									$risk="<span class='label label-success'>Low</span>";
									$model_class="modal-success";
									}
									
									$supervisor_comment= $value_ews['ews_detail']['comment'];
										if($supervisor_comment!='') {
										$comment_new=$supervisor_comment;
										}else{
										 $comment_new='N/A';
										}
										
										$supervisor_action_plan= $value_ews['ews_detail']['action_plan'];
										if($supervisor_action_plan!='') {
										$action_plan_new=$supervisor_action_plan;
										}else{
										 $action_plan_new='N/A';
										}
								 ?>
                  <tr>
                    <td><?php   $first_name=$mysql->get('users','first_name','user_id='.$emp_id);
								$last_name=$mysql->get('users','last_name','user_id='.$emp_id);
								$username=$mysql->get('users','username','user_id='.$emp_id);
								echo $first_name.' '.$last_name.' ('.$username.')';
								 ?></td>
					<td><?php   $filledby_fname=$mysql->get('users','first_name','user_id='.$supervisor_detail);
					            $filledby_lname=$mysql->get('users','last_name','user_id='.$supervisor_detail);
								$filledby_id=$mysql->get('users','username','user_id='.$supervisor_detail);
								echo $filledby_fname.'&nbsp;'.$filledby_lname.' ('.$filledby_id.')';
								?></td>			
                    <td><?php echo date('F Y', strtotime($value_ews['ews_detail']['assesment_month'])); ?></td>
					<td><?php echo date('d F Y', strtotime($value_ews['ews_detail']['meeting_date'])); ?></td>
                    <td><?php echo date('d F Y', strtotime($value_ews['ews_detail']['created_date'])); ?></td>
					<td><?php echo $criticality; ?></td>
                    <td><?php echo $risk; ?></td>
                    <td style="cursor:pointer;"><i class="fa fa-eye" aria-hidden="true" data-toggle="modal" data-target="#modal-<?php echo $id; ?>" ></i>
                      <div class="modal <?php echo $model_class; ?> fade" id="modal-<?php echo $id; ?>">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title" align="center"><?php echo $first_name.' '.$last_name.' ('.$username.')';?></h4>
                            </div>
                            <div class="modal-body" style="background:none!important;">
                              <div class="box-body table-responsive no-padding">
                                <table class="table table-striped" style="color:#000000">
                                  <tbody>
                                    <tr>
                                      <td width="25%">Business Unit:</td>
                                      <td width="25%"><?php echo $business_name;?></td>
                                      <td width="25%">Department:</td>
                                      <td width="25%"><?php echo $department;?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Employee Details:</td>
                                      <td width="25%"><?php echo $first_name.' '.$last_name.' ('.$username.')';;?></td>
                                      <td width="25%">Supervisor Details:</td>
                                      <td width="25%"><?php 
										$manager_name=$mysql->get('users','manager_name','user_id='.$emp_id);
										$manager_id=$mysql->get('users','manager_id','user_id='.$emp_id);
										echo $manager_name.' ('.$manager_id.')';
										//echo $mfirst_name.' '.$mlast_name.'('.$musername.')';
										?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Filled By:</td>
                                      <td width="25%"><?php   $filledby_fname=$mysql->get('users','first_name','user_id='.$supervisor_detail);
													$filledby_lname=$mysql->get('users','last_name','user_id='.$supervisor_detail);
													$filledby_id=$mysql->get('users','username','user_id='.$supervisor_detail);
													echo $filledby_fname.'&nbsp;'.$filledby_lname.' ('.$filledby_id.')';
													?></td>
                                      <td width="25%">Month Of Assesment:</td>
                                      <td width="25%"><?php echo date('F Y', strtotime($value_ews['ews_detail']['assesment_month'])); ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Meet up Date:</td>
                                      <td width="25%"><?php echo date('d F Y', strtotime($value_ews['ews_detail']['meeting_date'])); ?></td>
                                      <td width="25%">Emp Status:</td>
                                      <td width="25%"><?php
													 $status=$mysql->get('users','status','user_id='.$emp_id);
													 if($status==0)
													 {
													   echo "<span class='label label-success'>Active</span>";
													 }
													 else
													 {
													  echo "<span class='label label-danger'>Resigned</span>";
													 }
													 ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Performance:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['performance']; ?></td>
                                      <td width="25%">Leave:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['leave_r']; ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">External Interviews:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['external_interviews']; ?></td>
                                      <td width="25%">Behavior/ Motivation:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['behavior_motivation']; ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Personal Effectiveness:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['personal_effectiveness']; ?></td>
                                      <td width="25%">Career Growth:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['career_growth']; ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Skill Set:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['skill_set']; ?></td>
                                      <td width="25%">1 to 1 Assessment:</td>
                                      <td width="25%"><?php echo $value_ews['ews_detail']['one_on_one_ass']; ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Action:</td>
                                      <td width="75%" colspan="3"><?php echo $action_plan_new; ?></td>
                                    </tr>
                                    <tr>
                                      <td width="25%">Comment:</td>
                                      <td width="75%" colspan="3"><?php echo $comment_new; ?></td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button class="btn btn-outline" onClick="PrintFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
                              <button type="button" class="btn btn-outline" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div></td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <?php $halfPages = floor($numberOfPages / 2);
					$range = array('start' => 1, 'end' => $totalPages);
					$isEven = ($numberOfPages % 2 == 0);
					$atRangeEnd = $totalPages - $halfPages;
					
					if($isEven) $atRangeEnd++;
					
					if($totalPages > $numberOfPages)
					{
						if($page <= $halfPages)
							$range['end'] = $numberOfPages;
						elseif ($page >= $atRangeEnd)
							$range['start'] = $totalPages - $numberOfPages + 1;
						else
						{
							$range['start'] = $page - $halfPages;
							$range['end'] = $page + $halfPages;
							if($isEven) $range['end']--;
						}
					} if($totalPages>1) {  
			   if(isset($_REQUEST['filter_submit']))
                  {		?>
              <ul class="pagination pagination-sm no-margin pull-right">
                <?php if($page > 1)
					echo '<li class="button"><a href="'.$_SERVER['REQUEST_URI'].'&page='.($page - 1).'">&laquo; Previous</a>&nbsp<li>';
				
				for ($i = $range['start']; $i <= $range['end']; $i++)
				{
					if($i == $page)
						echo '<li class="active"><a class="current" href="#">'.$i.'</a></li>';
					else
						echo ' <li><a href="'.$_SERVER['REQUEST_URI'].'&page='.$i.'">'.$i.'</a> </li>';
				}
				if ($page < $totalPages)
					echo ' <li class="button"><a href="'.$_SERVER['REQUEST_URI'].'&page='.($page + 1).'">Next &raquo; </a></li>'; ?>
              </ul>
              <?php } else { ?>
              <ul class="pagination pagination-sm no-margin pull-right">
                <?php if($page > 1)
					echo '<li class="button"><a href="?page='.($page - 1).'">&laquo; Previous</a>&nbsp<li>';
				
				for ($i = $range['start']; $i <= $range['end']; $i++)
				{
					if($i == $page)
						echo '<li class="active"><a class="current" href="#">'.$i.'</a></li>';
					else
						echo ' <li><a href="?page='.$i.'">'.$i.'</a> </li>';
				}
				if ($page < $totalPages)
					echo ' <li class="button"><a href="?page='.($page + 1).'">Next &raquo; </a></li>'; ?>
              </ul>
              <?php } 
			       } ?>
            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <?php include_once('includes/footer.php'); ?>
</div>
<!-- ./wrapper -->
<?php include_once('includes/alljs.php'); ?>
<script  type="text/javascript">
	$(document).ready(function() {
	
		jQuery('#export-menu li').bind("click", function() {
			var target = $(this).attr('id');
			switch(target) {
				case 'export-to-excel' :
				$('#hidden-type').val(target);
				//alert($('#hidden-type').val());
				$('#export-form').submit();
				$('#hidden-type').val('');
				break
				case 'export-to-csv' :
				$('#hidden-type').val(target);
				//alert($('#hidden-type').val());
				$('#export-form').submit();
				$('#hidden-type').val('');
				break
			}
		});
    });
</script>
</body>
</html>
