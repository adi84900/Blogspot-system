<script type="text/javascript">
            var chart;
            var chartData = [
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -11 month'));?>',
                    "highrisk": <?php echo $count_r_r_twelve; ?>,
                    "mediumrisk": <?php echo $count_r_y_twelve; ?>,
                    "lowrisk": <?php echo $count_r_g_twelve; ?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -11 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -11 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -11 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -10 month'));?>',
                    "highrisk": <?php echo $count_r_r_eleven;?>,
                    "mediumrisk": <?php echo $count_r_y_eleven;?>,
                    "lowrisk": <?php echo $count_r_g_eleven;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -10 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -10 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -10 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -9 month'));?>',
                    "highrisk": <?php echo $count_r_r_ten;?>,
                    "mediumrisk": <?php echo $count_r_y_ten;?>,
                    "lowrisk": <?php echo $count_r_g_ten;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -9 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -9 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -9 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -8 month'));?>',
                    "highrisk": <?php echo $count_r_r_nine;?>,
                    "mediumrisk": <?php echo $count_r_y_nine;?>,
                    "lowrisk": <?php echo $count_r_g_nine;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -8 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -8 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -8 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -7 month'));?>',
                    "highrisk": <?php echo $count_r_r_eight;?>,
                    "mediumrisk": <?php echo $count_r_y_eight;?>,
                    "lowrisk": <?php echo $count_r_g_eight;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -7 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -7 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -7 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -6 month'));?>',
                    "highrisk": <?php echo $count_r_r_seven;?>,
                    "mediumrisk": <?php echo $count_r_y_seven;?>,
                    "lowrisk": <?php echo $count_r_g_seven;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -6 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -6 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -6 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -5 month'));?>',
                    "highrisk": <?php echo $count_r_r_six;?>,
                    "mediumrisk": <?php echo $count_r_y_six;?>,
                    "lowrisk": <?php echo $count_r_g_six;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -5 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -5 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -5 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -4 month'));?>',
                    "highrisk": <?php echo $count_r_r_five;?>,
                    "mediumrisk": <?php echo $count_r_y_five;?>,
                    "lowrisk": <?php echo $count_r_g_five;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -4 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -4 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -4 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -3 month'));?>',
                     "highrisk": <?php echo $count_r_r_four;?>,
                    "mediumrisk": <?php echo $count_r_y_four;?>,
                    "lowrisk": <?php echo $count_r_g_four;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -3 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -3 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -3 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -2 month'));?>',
                    "highrisk": <?php echo $count_r_r_one;?>,
                    "mediumrisk": <?php echo $count_r_y_one;?>,
                    "lowrisk": <?php echo $count_r_g_one;?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "month": '<?php echo date('M Y', strtotime('first day of -1 month'));?>',
                    "highrisk": <?php echo $count_r_r_two; ?>,
                    "mediumrisk": <?php echo $count_r_y_two; ?>,
                    "lowrisk": <?php echo $count_r_g_two; ?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
				{
                    "month": '<?php echo date('M Y', strtotime('first day of this month'));?>',
                    "highrisk": <?php echo $count_r_r_three; ?>,
                    "mediumrisk": <?php echo $count_r_y_three; ?>,
                    "lowrisk": <?php echo $count_r_g_three; ?>,
					"urlhighrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urlmediumrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
					"urllowrisk": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                }
            ];
            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "month";
                chart.startDuration = .3;
                chart.balloon.color = "#000000";

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.fillAlpha = 1;
                categoryAxis.fillColor = "#FAFAFA";
                categoryAxis.gridAlpha = 0;
                categoryAxis.axisAlpha = 0;
				categoryAxis.title = "Months";
                categoryAxis.gridPosition = "start";
                categoryAxis.position = "bottom";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.dashLength = 5;
                valueAxis.axisAlpha = 0;
                valueAxis.integersOnly = true;
				valueAxis.title = "Risk Score";
                valueAxis.gridCount = 10;
                valueAxis.reversed = false; // this line makes the value axis reversed
                chart.addValueAxis(valueAxis);

                // GRAPHS
                // High Risk graph
                var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
				graph.lineColor = "#dd4b39";
                graph.valueField = "highrisk";
				graph.urlField = "urlhighrisk";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.bullet = "round";
				graph.bulletSize = 15;
				graph.lineThickness = 1.5;
                chart.addGraph(graph);

                // Medium Risk graph
                var graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
				graph.lineColor = "#f39c12";
                graph.valueField = "mediumrisk";
				graph.urlField = "urlmediumrisk";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.bullet = "round";
				graph.bulletSize = 10;
				graph.lineThickness = 1.5;
                chart.addGraph(graph);

                // Low Risk graph
                var graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
				graph.lineColor = "#00a65a";
                graph.valueField = "lowrisk";
				graph.urlField = "urllowrisk";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.bullet = "round";
				graph.bulletSize = 8;
				graph.lineThickness = 1.5;
                chart.addGraph(graph);

                // WRITE
                chart.write("chartdivtrends");
            });
        </script>
<script type="text/javascript">
var gaugeChart = AmCharts.makeChart("chartdiv_gauge", {
  "type": "gauge",
  "theme": "light",
  "axes": [{
    "axisAlpha": 0,
    "tickAlpha": 0,
    "labelsEnabled": false,
    "startValue": 0,
    "endValue": 100,
    "startAngle": 0,
    "endAngle": 270,
    "bands": [{
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "100%",
      "innerRadius": "85%"
    }, {
      "color": "#00a65a",
      "startValue": 0,
      "endValue": <?php echo ($count_r_g_gaugeone / 100) * $num_rows_gauge_one; ?>,
      "radius": "100%",
      "innerRadius": "85%",
      "balloonText": "<?php echo ($count_r_g_gaugeone / 100) * $num_rows_gauge_one; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "80%",
      "innerRadius": "65%"
    }, {
      "color": "#f39c12",
      "startValue": 0,
      "endValue": <?php echo ($count_r_y_gaugeone/ 100) * $num_rows_gauge_one; ?>,
      "radius": "80%",
      "innerRadius": "65%",
      "balloonText": "<?php echo ($count_r_y_gaugeone/ 100) * $num_rows_gauge_one; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "60%",
      "innerRadius": "45%"
    }, {
      "color": "#dd4b39",
      "startValue": 0,
      "endValue": <?php echo ($count_r_r_gaugeone/ 100) * $num_rows_gauge_one; ?>,
      "radius": "60%",
      "innerRadius": "45%",
      "balloonText": "<?php echo ($count_r_r_gaugeone/ 100) * $num_rows_gauge_one; ?>%"
    }]
  }],
  "allLabels": [{
    "text": "Low Risk",
    "x": "49%",
    "y": "5%",
    "size": 15,
    "bold": true,
    "color": "#00a65a",
    "align": "right"
  }, {
    "text": "Medium Risk",
    "x": "49%",
    "y": "15%",
    "size": 15,
    "bold": true,
    "color": "#f39c12",
    "align": "right"
  }, {
    "text": "High Risk",
    "x": "49%",
    "y": "24%",
    "size": 15,
    "bold": true,
    "color": "#dd4b39",
    "align": "right"
  }],
  "export": {
    "enabled": false
  }
});
</script>
<script type="text/javascript">
var gaugeChart = AmCharts.makeChart("chartdiv_gauge_two", {
  "type": "gauge",
  "theme": "light",
  "axes": [{
    "axisAlpha": 0,
    "tickAlpha": 0,
    "labelsEnabled": false,
    "startValue": 0,
    "endValue": 100,
    "startAngle": 0,
    "endAngle": 270,
    "bands": [{
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "100%",
      "innerRadius": "85%"
    }, {
      "color": "#00a65a",
      "startValue": 0,
      "endValue": <?php echo ($count_r_g_gaugetwo / 100) * $num_rows_gauge_two; ?>,
      "radius": "100%",
      "innerRadius": "85%",
      "balloonText": "<?php echo ($count_r_g_gaugetwo / 100) * $num_rows_gauge_two; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "80%",
      "innerRadius": "65%"
    }, {
      "color": "#f39c12",
      "startValue": 0,
      "endValue": <?php echo ($count_r_y_gaugetwo/ 100) * $num_rows_gauge_two; ?>,
      "radius": "80%",
      "innerRadius": "65%",
      "balloonText": "<?php echo ($count_r_y_gaugetwo/ 100) * $num_rows_gauge_two; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "60%",
      "innerRadius": "45%"
    }, {
      "color": "#dd4b39",
      "startValue": 0,
      "endValue": <?php echo ($count_r_r_gaugetwo/ 100) * $num_rows_gauge_two; ?>,
      "radius": "60%",
      "innerRadius": "45%",
      "balloonText": "<?php echo ($count_r_r_gaugetwo/ 100) * $num_rows_gauge_two; ?>%"
    }]
  }],
  "allLabels": [{
    "text": "Low Risk",
    "x": "49%",
    "y": "5%",
    "size": 15,
    "bold": true,
    "color": "#00a65a",
    "align": "right"
  }, {
    "text": "Medium Risk",
    "x": "49%",
    "y": "15%",
    "size": 15,
    "bold": true,
    "color": "#f39c12",
    "align": "right"
  }, {
    "text": "High Risk",
    "x": "49%",
    "y": "24%",
    "size": 15,
    "bold": true,
    "color": "#dd4b39",
    "align": "right"
  }],
  "export": {
    "enabled": false
  }
});
</script>
<script type="text/javascript">
var gaugeChart = AmCharts.makeChart("chartdiv_gauge_three", {
  "type": "gauge",
  "theme": "light",
  "axes": [{
    "axisAlpha": 0,
    "tickAlpha": 0,
    "labelsEnabled": false,
    "startValue": 0,
    "endValue": 100,
    "startAngle": 0,
    "endAngle": 270,
    "bands": [{
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "100%",
      "innerRadius": "85%"
    }, {
      "color": "#00a65a",
      "startValue": 0,
      "endValue": <?php echo ($count_r_g_gaugethree / 100) * $num_rows_gauge_three; ?>,
      "radius": "100%",
      "innerRadius": "85%",
      "balloonText": "<?php echo ($count_r_g_gaugethree / 100) * $num_rows_gauge_three; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "80%",
      "innerRadius": "65%"
    }, {
      "color": "#f39c12",
      "startValue": 0,
      "endValue": <?php echo ($count_r_y_gaugethree/ 100) * $num_rows_gauge_three; ?>,
      "radius": "80%",
      "innerRadius": "65%",
      "balloonText": "<?php echo ($count_r_y_gaugethree/ 100) * $num_rows_gauge_three; ?>%"
    }, {
      "color": "#eee",
      "startValue": 0,
      "endValue": 100,
      "radius": "60%",
      "innerRadius": "45%"
    }, {
      "color": "#dd4b39",
      "startValue": 0,
      "endValue": <?php echo ($count_r_r_gaugethree/ 100) * $num_rows_gauge_three; ?>,
      "radius": "60%",
      "innerRadius": "45%",
      "balloonText": "<?php echo ($count_r_r_gaugethree/ 100) * $num_rows_gauge_three; ?>%"
    }]
  }],
  "allLabels": [{
    "text": "Low Risk",
    "x": "49%",
    "y": "5%",
    "size": 15,
    "bold": true,
    "color": "#00a65a",
    "align": "right"
  }, {
    "text": "Medium Risk",
    "x": "49%",
    "y": "15%",
    "size": 15,
    "bold": true,
    "color": "#f39c12",
    "align": "right"
  }, {
    "text": "High Risk",
    "x": "49%",
    "y": "24%",
    "size": 15,
    "bold": true,
    "color": "#dd4b39",
    "align": "right"
  }],
  "export": {
    "enabled": false
  }
});
</script>
<script type="text/javascript">
            var chart;
			<?php if($count_r_g!='') { ?>
            var chartDatapie = [
                {
                    "risk": "High Risk",
                    "count": <?php echo $count_r_r; ?>,
					"color": "#dd4b39",
		            "url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Medium Risk",
                    "count": <?php echo $count_r_y; ?>,
					"color": "#f39c12",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Low Risk",
                    "count": <?php echo $count_r_g; ?>,
					"color": "#00a65a",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=&fromdate_filter=&todate_filter=&filter_submit="
                }
            ];
            AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                // title of the chart
                chart.dataProvider = chartDatapie;
                chart.titleField = "risk";
                chart.valueField = "count";
				chart.colorField = "color";
				chart.urlField = "url";
                chart.sequencedAnimation = true;
                chart.startEffect = "elastic";
                chart.innerRadius = "50%";
                chart.startDuration = 2;
                chart.labelRadius = 15;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // the following two lines makes the chart 3D
				chart.labelsEnabled= false;
				chart.autoMargins= false;
				chart.marginTop= 0;
				chart.marginBottom= 0;
				chart.marginLeft= 0;
				chart.marginRight= 0;
				chart.pullOutRadius= 10;
				chart.depth3D = 20;
                chart.angle = 35;

                // WRITE
                chart.write("chartdivpie");
            });
			<?php } ?>
			<?php if($count_r_g_one!='') { ?>
			var chartDatapieOne = [
                {
                    "risk": "High Risk",
                    "count": <?php echo $count_r_r_one; ?>,
					"color": "#dd4b39",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Medium Risk",
                    "count": <?php echo $count_r_y_one; ?>,
					"color": "#f39c12",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Low Risk",
                    "count": <?php echo $count_r_g_one; ?>,
					"color": "#00a65a",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -2 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                }
            ];
			 AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                // title of the chart
                chart.dataProvider = chartDatapieOne;
                chart.titleField = "risk";
                chart.valueField = "count";
				chart.colorField = "color";
				chart.urlField = "url";
                chart.sequencedAnimation = true;
                chart.startEffect = "elastic";
                chart.innerRadius = "50%";
                chart.startDuration = 2;
                chart.labelRadius = 15;
				chart.labelsEnabled= false;
				chart.autoMargins= false;
				chart.marginTop= 0;
				chart.marginBottom= 0;
				chart.marginLeft= 0;
				chart.marginRight= 0;
				chart.pullOutRadius= 10;
				chart.depth3D = 20;
                chart.angle = 35;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // WRITE
                chart.write("chartdivpie_one");
            });
			<?php } ?>
			<?php if($count_r_g_two!='') { ?>
			var chartDatapieTwo = [
                {
                    "risk": "High Risk",
                    "count": <?php echo $count_r_r_two; ?>,
					"color": "#dd4b39",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Medium Risk",
                    "count": <?php echo $count_r_y_two; ?>,
					"color": "#f39c12",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Low Risk",
                    "count": <?php echo $count_r_g_two; ?>,
					"color": "#00a65a",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of -1 month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                }
            ];
			 AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                // title of the chart
                chart.dataProvider = chartDatapieTwo;
                chart.titleField = "risk";
                chart.valueField = "count";
				chart.colorField = "color";
				chart.urlField = "url";
                chart.sequencedAnimation = true;
                chart.startEffect = "elastic";
                chart.innerRadius = "50%";
                chart.startDuration = 2;
                chart.labelRadius = 15;
				chart.labelsEnabled= false;
				chart.autoMargins= false;
				chart.marginTop= 0;
				chart.marginBottom= 0;
				chart.marginLeft= 0;
				chart.marginRight= 0;
				chart.pullOutRadius= 10;
				chart.depth3D = 20;
                chart.angle = 35;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // WRITE
                chart.write("chartdivpie_two");
            });
			<?php } ?>
			<?php if($count_r_g_three!='') { ?>
			var chartDatapieThree = [
                {
                    "risk": "High Risk",
                    "count": <?php echo $count_r_r_three; ?>,
					"color": "#dd4b39",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Medium Risk",
                    "count": <?php echo $count_r_y_three; ?>,
					"color": "#f39c12",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                },
                {
                    "risk": "Low Risk",
                    "count": <?php echo $count_r_g_three; ?>,
					"color": "#00a65a",
					"url": "<?php echo BASE_URL; ?>/risk_wise_hr.php?ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
                }
            ];
			 AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                // title of the chart
                chart.dataProvider = chartDatapieThree;
                chart.titleField = "risk";
                chart.valueField = "count";
				chart.colorField = "color";
				chart.urlField = "url";
                chart.sequencedAnimation = true;
                chart.startEffect = "elastic";
                chart.innerRadius = "50%";
                chart.startDuration = 2;
                chart.labelRadius = 15;
				chart.labelsEnabled= false;
				chart.autoMargins= false;
				chart.marginTop= 0;
				chart.marginBottom= 0;
				chart.marginLeft= 0;
				chart.marginRight= 0;
				chart.pullOutRadius= 10;
				chart.depth3D = 20;
                chart.angle = 35;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // WRITE
                chart.write("chartdivpie_three");
            });
			<?php } ?>
        </script>
<script type="text/javascript">
   jQuery(document).ready(function(){
                jQuery("#chartdiv_text_parichay_new").fadeOut(300);
				jQuery("#chartdiv_amdm").fadeIn(500);
				 var chart;
			     var chartData = [
				  <?php 
								
								 $department_id=$_SESSION['hr_department'];
								 $mysql=new mysql();
								 $manager_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'department IN ('.$department_id.') and status=0 and user_type=5','order'=>'first_name'));
								  foreach($manager_list as $key=>$valuesmanager)
									 {
									     $high_risk=0;
										 $medium_risk=0;
										 $low_risk=0;
									 
									  ?>
						{
							"managername": '<?php echo $valuesmanager['users']['first_name'].' '.$valuesmanager['users']['last_name'].'('.$valuesmanager['users']['username'].')'; ?>',
							<?php $ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'YEAR(assesment_month) = YEAR(CURRENT_DATE()) AND MONTH(assesment_month) = MONTH(CURRENT_DATE()) and manager_detail ='.$valuesmanager['users']['user_id'].''));
							 foreach($ews_detail as $key=>$ews_details)
									 {
							$events_detail_total=$ews_details['ews_detail']['one_on_one_ass']+$ews_details['ews_detail']['performance']+$ews_details['ews_detail']['leave_r']+$ews_details['ews_detail']['external_interviews']+$ews_details['ews_detail']['behavior_motivation']+$ews_details['ews_detail']['personal_effectiveness']+$ews_details['ews_detail']['career_growth']+$ews_details['ews_detail']['skill_set'];	
							 if($events_detail_total <= 23){
								  $high_risk=$high_risk+1;
								}elseif($events_detail_total  >= 24 && $events_detail_total  <= 29){
								  $medium_risk=$medium_risk+1;
								}elseif($events_detail_total >= 30){
								  $low_risk=$low_risk+1;
								}	 
							 ?>
						<?php } ?>
						        "highrisk": <?php echo $high_risk;?>,
								"mediumrisk":<?php echo $medium_risk;?>,
								"lowrisk": <?php echo $low_risk;?>,
								"urlhigh": "<?php echo BASE_URL; ?>/manager_wise.php?manager_detail=<?php echo $valuesmanager['users']['user_id']; ?>&ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
								"urlmed": "<?php echo BASE_URL; ?>/manager_wise.php?manager_detail=<?php echo $valuesmanager['users']['user_id']; ?>&ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
								"urllow": "<?php echo BASE_URL; ?>/manager_wise.php?manager_detail=<?php echo $valuesmanager['users']['user_id']; ?>&ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
						},
					<?php	} ?>
					];
					
                // SERIALL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "managername";
                chart.plotAreaBorderAlpha = 0.2;
                chart.rotate = true;
				chart.depth3D = 5;
				chart.angle = 10;
				chart.startDuration = 3;

                // AXES
                // Category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0.1;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPHS
				// third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "lowrisk";
				graph.urlField = "urllow";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#00a65a";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
				 // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "mediumrisk";
				graph.urlField = "urlmed";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#f39c12";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
                // firstgraph
                 var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "highrisk";
				graph.urlField = "urlhigh";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#dd4b39";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
                // WRITE
                chart.write("chartdiv_amdm");	
 });  
       
</script>		
<script type="text/javascript">
jQuery(document).ready(function() {
           jQuery.ajax({
				type: 'post',
				url: '<?php echo BASE_URL; ?>/inc/data_graph_hr_criteria_behave.php',
				success: function(data) {
				jQuery("#chartdiv_oneonone").fadeIn(500);
				//alert(arr[0]);
				 var arr = data.split('::::');
				 var one = arr[0];
				 var two = arr[1];
				 var three = arr[2];
				 //alert(one+'+++++'+two+'======'+three);
				 
				 high_risk = one.split(',');
				 medium_risk = two.split(',');
				 low_risk = three.split(',');
                 
				 var chart;
			     var chartData = [
						{
							"criteria": 'Leaves',
							"highrisk": high_risk[0],
							"mediumrisk": medium_risk[0],
							"lowrisk": low_risk[0],
							
						},
						 {
							"criteria": 'Productivity issue',
							"highrisk": high_risk[1],
							"mediumrisk": medium_risk[1],
							"lowrisk": low_risk[1],
							
						},
						{
							"criteria": 'Performance dips',
							"highrisk": high_risk[2],
							"mediumrisk": medium_risk[2],
							"lowrisk": low_risk[2],
							
						},
						{
							"criteria": 'Interest issue',
							"highrisk": high_risk[3],
							"mediumrisk": medium_risk[3],
							"lowrisk": low_risk[3],
							
						},
						{
							"criteria": 'Leave issue',
							"highrisk": high_risk[4],
							"mediumrisk": medium_risk[4],
							"lowrisk": low_risk[4],
							
						},
						{
							"criteria": 'Forgets meetings',
							"highrisk": high_risk[5],
							"mediumrisk": medium_risk[5],
							"lowrisk": low_risk[5],
							
						},
						{
							"criteria": 'Late comings',
							"highrisk": high_risk[6],
							"mediumrisk": medium_risk[6],
							"lowrisk": low_risk[6],
							
						},
						{
							"criteria": 'Dressing issue',
							"highrisk": high_risk[7],
							"mediumrisk": medium_risk[7],
							"lowrisk": low_risk[7],
							
						},
						{
							"criteria": 'Creativity issue',
							"highrisk": high_risk[8],
							"mediumrisk": medium_risk[8],
							"lowrisk": low_risk[8],
							
						},
						{
							"criteria": 'Energy issue',
							"highrisk": high_risk[9],
							"mediumrisk": medium_risk[9],
							"lowrisk": low_risk[9],
							
						},
						{
							"criteria": 'Growth issue',
							"highrisk": high_risk[10],
							"mediumrisk": medium_risk[10],
							"lowrisk": low_risk[10],
							
						},
						{
							"criteria": 'Spreads negativity',
							"highrisk": high_risk[11],
							"mediumrisk": medium_risk[11],
							"lowrisk": low_risk[11],
							
						},
						{
							"criteria": 'Excitement  issue',
							"highrisk": high_risk[12],
							"mediumrisk": medium_risk[12],
							"lowrisk": low_risk[12],

							
						},
						{
							"criteria": 'Arrogant',
							"highrisk": high_risk[13],
							"mediumrisk": medium_risk[13],
							"lowrisk": low_risk[13],
							
						},
						{
							"criteria": 'Appraisal issue',
							"highrisk": high_risk[14],
							"mediumrisk": medium_risk[14],
							"lowrisk": low_risk[14],
							
						},
						{
							"criteria": 'Attending interviews',
							"highrisk": high_risk[15],
							"mediumrisk": medium_risk[15],
							"lowrisk": low_risk[15],
							
						},
						{
							"criteria": 'Permissions for interviews',
							"highrisk": high_risk[16],
							"mediumrisk": medium_risk[16],
							"lowrisk": low_risk[16],
							
						}
					];
		
				  // AmCharts.ready(function () {
                // SERIALL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "criteria";
                chart.plotAreaBorderAlpha = 0.2;
                chart.rotate = true;
				chart.depth3D = 5;
				chart.angle = 10;
				chart.startDuration = 3;

                // AXES
                // Category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0.1;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPHS
				// third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "lowrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#00a65a";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
				 // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "mediumrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#f39c12";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
                // firstgraph
                var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "highrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#dd4b39";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);

                chart.write("chartdiv_rating_behave");
           // });
			}
  }); 
});  
</script>	
<script type="text/javascript">
jQuery(document).ready(function() {
           jQuery.ajax({
				type: 'post',
			//	data: 'department_id='+<?php echo $_SESSION['hr_department']; ?>,
				url: '<?php echo BASE_URL; ?>/inc/data_graph_hr_criteria_oneonone.php',
				success: function(data) {
				jQuery("#chartdiv_oneonone").fadeIn(500);
				//alert(arr[0]);
				 var arr = data.split('::::');
				 var one = arr[0];
				 var two = arr[1];
				 var three = arr[2];
				 //alert(one+'+++++'+two+'======'+three);
				 
				 high_risk = one.split(',');
				 medium_risk = two.split(',');
				 low_risk = three.split(',');
                 
				 var chart;
			     var chartData = [
						{
							"criteria": 'Redeployment',
							"highrisk": high_risk[0],
							"mediumrisk": medium_risk[0],
							"lowrisk": low_risk[0],
							
						},
						{
							"criteria": 'Marriage in offering',
							"highrisk": high_risk[1],
							"mediumrisk": medium_risk[1],
							"lowrisk": low_risk[1],
							
						},
						{
							"criteria": 'Night shift',
							"highrisk": high_risk[2],
							"mediumrisk": medium_risk[2],
							"lowrisk": low_risk[2],
							
						},
						{
							"criteria": 'Family problems',
							 "highrisk": high_risk[3],
							"mediumrisk": medium_risk[3],
							"lowrisk": low_risk[3],
							
						},
						{
							"criteria": 'Salary',
							 "highrisk": high_risk[4],
							"mediumrisk": medium_risk[4],
							"lowrisk": low_risk[4],
							
						},
						{
							"criteria": 'Higher education',
							 "highrisk": high_risk[5],
							"mediumrisk": medium_risk[5],
							"lowrisk": low_risk[5],
							
						},
						{
							"criteria": 'Medical problems',
							 "highrisk": high_risk[6],
							"mediumrisk": medium_risk[6],
							"lowrisk": low_risk[6],
							
						},
						{
							 "criteria": 'Warnings',
							 "highrisk": high_risk[7],
							"mediumrisk": medium_risk[7],
							"lowrisk": low_risk[7],
							
						},
						{
							 "criteria": 'Maternity',
							 "highrisk": high_risk[8],
							"mediumrisk": medium_risk[8],
							"lowrisk": low_risk[8],
						}
					];
		
				  // AmCharts.ready(function () {
                // SERIALL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "criteria";
                chart.plotAreaBorderAlpha = 0.2;
                chart.rotate = true;
				chart.depth3D = 5;
				chart.angle = 10;
				chart.startDuration = 3;

                // AXES
                // Category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0.1;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPHS
				// third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "lowrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#00a65a";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
				 // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "mediumrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#f39c12";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
                // firstgraph
                var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "highrisk";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#dd4b39";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);

                chart.write("chartdiv_oneonone");
           // });
			}
  }); 
});    
</script>
<script type="text/javascript">
jQuery(document).ready(function() {
           jQuery.ajax({
				type: 'post',
				//data: 'department_id='+<?php echo $_SESSION['hr_department']; ?>,
				url: '<?php echo BASE_URL; ?>/inc/data_graph-amdm_hr_criteria.php',
				success: function(data) {
			    jQuery("#chartdiv_text_contracts_new").fadeOut(300);
				jQuery("#chartdiv_rating").fadeIn(500);
				//alert(arr[0]);
				 var arr = data.split('::::');
				 var one = arr[0];
				 var two = arr[1];
				 var three = arr[2];
				 //alert(one+'+++++'+two+'======'+three);
				 
				 high_risk = one.split(',');
				 medium_risk = two.split(',');
				 low_risk = three.split(',');
                 
				 var chart;
			     var chartData = [
						{
							"criteria": '1 ON 1 Assessment',
							"highrisk": high_risk[0],
							"mediumrisk": medium_risk[0],
							"lowrisk": low_risk[0],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?assessment=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?assessment=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?assessment=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							"criteria": 'Performance',
							"highrisk": high_risk[1],
							"mediumrisk": medium_risk[1],
							"lowrisk": low_risk[1],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?performance=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?performance=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?performance=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							"criteria": 'Leave',
							"highrisk": high_risk[2],
							"mediumrisk": medium_risk[2],
							"lowrisk": low_risk[2],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?leave=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?leave=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?leave=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							"criteria": 'External Interviews',
							 "highrisk": high_risk[3],
							"mediumrisk": medium_risk[3],
							"lowrisk": low_risk[3],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?interviews=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?interviews=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?interviews=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							"criteria": 'Behavior',
							 "highrisk": high_risk[4],
							"mediumrisk": medium_risk[4],
							"lowrisk": low_risk[4],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?behavior=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?behavior=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?behavior=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},

						{
							"criteria": 'Effectiveness',
							 "highrisk": high_risk[5],
							"mediumrisk": medium_risk[5],
							"lowrisk": low_risk[5],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?effectiveness=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?effectiveness=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?effectiveness=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							"criteria": 'Career Growth',
							 "highrisk": high_risk[6],
							"mediumrisk": medium_risk[6],
							"lowrisk": low_risk[6],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?career=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?career=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?career=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							 "criteria": 'Skill Set',
							 "highrisk": high_risk[7],
							"mediumrisk": medium_risk[7],
							"lowrisk": low_risk[7],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?skill=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?skill=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?skill=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						},
						{
							 "criteria": 'Criticality',
							 "highrisk": high_risk[8],
							"mediumrisk": medium_risk[8],
							"lowrisk": low_risk[8],
							"urlhigh": "<?php echo BASE_URL; ?>/summary_report.php?criticality=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urlmed": "<?php echo BASE_URL; ?>/summary_report.php?criticality=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit=",
							"urllow": "<?php echo BASE_URL; ?>/summary_report.php?criticality=5&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&filter_submit="
						}
					];
		
				  // AmCharts.ready(function () {
                // SERIALL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "criteria";
                chart.plotAreaBorderAlpha = 0.2;
                chart.rotate = true;
				chart.depth3D = 5;
				chart.angle = 10;
				chart.startDuration = 3;

                // AXES
                // Category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0.1;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPHS
				// third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "lowrisk";
			//	graph.urlField = "urllow";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#00a65a";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
				 // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "mediumrisk";
				//graph.urlField = "urlmed";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#f39c12";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
                // firstgraph
                 var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "highrisk";
				//graph.urlField = "urlhigh";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#dd4b39";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
              
                // WRITE
                chart.write("chartdiv_rating");
           // });
			}
  }); 
}); 
</script>	
<script type="text/javascript">
   jQuery(document).ready(function(){
				jQuery("#chartdiv_process").fadeIn(500);
				 var chart;
			     var chartData = [
				  <?php 
								
								 $department_id=$_SESSION['hr_department'];
								 $mysql=new mysql();
								 $department_list= $mysql->select(array('table'=>'department_master','fields'=>'*','condition'=>'id IN ('.$department_id.')','order'=>'	department_name'));
								  foreach($department_list as $key=>$valuesdepartment)
									 {
									     $high_risk=0;
										 $medium_risk=0;
										 $low_risk=0;
									 
									  ?>
						{
							"departmentname": '<?php echo $valuesdepartment['department_master']['department_name']; ?>',
							<?php $ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'YEAR(assesment_month) = YEAR(CURRENT_DATE()) AND MONTH(assesment_month) = MONTH(CURRENT_DATE()) and department ='.$valuesdepartment['department_master']['id'].''));
							 foreach($ews_detail as $key=>$ews_details)
									 {
							$events_detail_total=$ews_details['ews_detail']['one_on_one_ass']+$ews_details['ews_detail']['performance']+$ews_details['ews_detail']['leave_r']+$ews_details['ews_detail']['external_interviews']+$ews_details['ews_detail']['behavior_motivation']+$ews_details['ews_detail']['personal_effectiveness']+$ews_details['ews_detail']['career_growth']+$ews_details['ews_detail']['skill_set'];	
							 if($events_detail_total <= 23){
								  $high_risk=$high_risk+1;
								}elseif($events_detail_total  >= 24 && $events_detail_total  <= 29){
								  $medium_risk=$medium_risk+1;
								}elseif($events_detail_total >= 30){
								  $low_risk=$low_risk+1;
								}	 
							 ?>
						<?php } ?>
						        "highrisk": <?php echo $high_risk;?>,
								"mediumrisk":<?php echo $medium_risk;?>,
								"lowrisk": <?php echo $low_risk;?>,
								"urlhigh": "<?php echo BASE_URL; ?>/process_wise.php?department=<?php echo $valuesdepartment['department_master']['id']; ?>&ews_status=1&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
								"urlmed": "<?php echo BASE_URL; ?>/process_wise.php?department=<?php echo $valuesdepartment['department_master']['id']; ?>&ews_status=2&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit=",
								"urllow": "<?php echo BASE_URL; ?>/process_wise.php?department=<?php echo $valuesdepartment['department_master']['id']; ?>&ews_status=3&assesment_month=<?php echo date('Y-m-d', strtotime('first day of this month'));?>&fromdate_filter=&todate_filter=&filter_submit="
						},
					<?php	} ?>
					];
					
                // SERIALL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "departmentname";
                chart.plotAreaBorderAlpha = 0.2;
                chart.rotate = true;
				chart.depth3D = 5;
				chart.angle = 10;
				chart.startDuration = 3;

                // AXES
                // Category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0.1;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPHS
				// third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "lowrisk";
				graph.urlField = "urllow";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#00a65a";
                graph.balloonText = "<span style='color:#00a65a'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
				 // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "mediumrisk";
				graph.urlField = "urlmed";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#f39c12";
                graph.balloonText = "<span style='color:#f39c12'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
				
                // firstgraph
                 var graph = new AmCharts.AmGraph();
                graph.title = "High Risk";
                graph.labelText = "[[value]]";
                graph.valueField = "highrisk";
				graph.urlField = "urlhigh";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#dd4b39";
                graph.balloonText = "<span style='color:#dd4b39'><b>[[title]]</b></span><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>";
                graph.labelPosition = "middle";
                chart.addGraph(graph);
                // WRITE
                chart.write("chartdiv_process");	
 });  
       
</script>