      <?php
						  $ews_detail=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'1=1'));
						    $count_r_r=0;
							$count_r_y=0;
							$count_r_g=0;
							$colors_r=0;
							$colors_y=0;
							$colors_g=0;
						  foreach($ews_detail as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								if($empstatus==0)
								{
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$colors_r="#FF0000";
									$count_r_r=$count_r_r+1;
									}
									else if($events_detail_total  > 36 && $events_detail_total  <= 38 )
									{
									$colors_y="#FF9933";
									$count_r_y=$count_r_y+1;
									}
									else if($events_detail_total >= 39)
									{
									$colors_g="#006600";
									$count_r_g=$count_r_g+1;
									}
									
								}
								}
						  ?>
      <div class="row">
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box"> <span class="info-box-icon bg-red"> <i class="ion ion-sad-outline"></i></span>
            <div class="info-box-content"> <span class="info-box-text">High Risk</span> <span class="info-box-number"><?php echo $count_r_r; ?></span> </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box"> <span class="info-box-icon bg-yellow"><i class="ion ion-android-sad"></i></span>
            <div class="info-box-content"> <span class="info-box-text">Medium Risk</span> <span class="info-box-number"><?php echo $count_r_y; ?></span> </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box"> <span class="info-box-icon bg-green"> <i class="ion ion-happy-outline"></i></span>
            <div class="info-box-content"> <span class="info-box-text">Low Risk</span> <span class="info-box-number"><?php echo $count_r_g; ?></span> </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-6">
          <div id="chartdiv" style="height:500px;"></div>
        </div>
        <div class="col-md-6">
          <div id="chartdivpie" style="height:500px;"></div>
        </div>
      </div>
