 <!-- /.content-wrapper -->
  <footer class="main-footer">
  <a id="back-to-top" href="#" class="scrollToTop"  style="display:none;"
	  role="button" title="Back to Top" data-toggle="tooltip" data-placement="top">
	  <span class="glyphicon glyphicon-chevron-up"></span>
	</a>
    <div class="pull-right hidden-xs">
      <b>Retention</b> 3.0.0
    </div>
    <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="http://www.quatrro.com/" target="_blank" class="text-green">Quatrro Global Services.</a></strong> All rights
    reserved.
  </footer>
 