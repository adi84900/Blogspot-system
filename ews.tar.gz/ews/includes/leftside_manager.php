<?php $activePage = basename($_SERVER['PHP_SELF'], ".php");
$bu_id=$_SESSION['business_unit'];
$department_id=$_SESSION['department'];
$manager_id=$_SESSION['username'];
$supervisor_detail=$_SESSION['userid'];
$mysql=new mysql(); 
$employee_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id.' and manager_id LIKE "%'.$manager_id.'%" and status=0 and user_type=6','order'=>'first_name'));
?>

<aside class="main-sidebar">
  <section class="sidebar">
    <ul class="sidebar-menu" data-widget="tree">
      <li class="<?=($activePage=='dashboard') ? 'active':''; ?>"><a href="dashboard.php"><i class="fa fa-desktop" style="color:#00a65a;"></i> <span> My Dashboard</span></a></li>
      <?php if(!empty($employee_list)) {  ?>
      <li class="treeview <?=($activePage=='manage_ews' or $activePage=='add_ews') ? 'active':''; ?>"> <a href="javascript:void();"> <i class="fa fa-users" style="color:#00a65a;"></i> <span> Manage Retention</span> <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span></a>
        <ul class="treeview-menu">
          <li class="<?=($activePage=='manage_ews') ? 'active':''; ?>"><a href="<?php echo BASE_URL; ?>/manage_ews.php"><i class="fa fa-circle-o"></i>View Retention</a></li>
          <li class="<?=($activePage=='add_ews') ? 'active':''; ?>"><a href="<?php echo BASE_URL; ?>/add_ews.php"><i class="fa fa-circle-o"></i>Add Retention</a></li>
        </ul>
      </li>
      <?php } ?>
      <li class="treeview <?=($activePage=='supervisor_wise' or $activePage=='risk_wise' or $activePage=='employee_wise') ? 'active':''; ?>"> <a href="javascript:void();"> <i class="fa  fa-bar-chart" style="color:#00a65a;"></i>  <span> Reports</span><span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span> </a>
        <ul class="treeview-menu">
          <li class="<?=($activePage=='supervisor_wise') ? 'active':''; ?>"><a href="<?php echo BASE_URL; ?>/supervisor_wise.php"><i class="fa fa-circle-o"></i>Supervisor Wise Report</a></li>
          <li class="<?=($activePage=='risk_wise') ? 'active':''; ?>"><a href="<?php echo BASE_URL; ?>/risk_wise.php"><i class="fa fa-circle-o"></i>Risk Wise Report</a></li>
          <li class="<?=($activePage=='employee_wise') ? 'active':''; ?>"><a href="<?php echo BASE_URL; ?>/employee_wise.php"><i class="fa fa-circle-o"></i>Employee Wise Report</a></li>
        </ul>
      </li>
    </ul>
  </section>
  <?php                          $bu_id=$_SESSION['business_unit'];
								 $department_id=$_SESSION['department'];
								 $manager_id=$_SESSION['username'];
								 $supervisor_detail=$_SESSION['userid'];
								 $mysql=new mysql(); ?>
  <div class="box box-success box-solid" id="active_users" style="width:95%; margin-left:5px;">
    <div class="box-header with-border">
      <h6 class="box-title">Current Retention</h6>
      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
      </div>
      <!-- /.box-tools -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <?php  $am_dm_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id.' and manager_id LIKE "%'.$manager_id.'%" and status=0 and user_type!=6','order'=>'first_name'));
								 if(!empty($am_dm_list)) { ?>
      <dl class="sidebar-menu" data-widget="tree">
        <?php 
								 
								  foreach($am_dm_list as $key=>$valuesamdm)
									 { 
					$num_rows_am_dm_list = $mysql->countRows(array('table'=>'users','fields'=>'*','condition'=>'manager_id="'.$valuesamdm['users']['username'].'" and status=0'));	 
									 ?>
        <dd class="treeview"> <a href="javascript: void(0);" style="color:#000000!important;"> <span class="glyphicon glyphicon-expand text-green" aria-hidden="true" style="color:#585151!important;"></span>&nbsp;<?php echo $valuesamdm['users']['first_name'].' '.substr($valuesamdm['users']['last_name'],0,6)."&nbsp;(".$valuesamdm['users']['username'].")"; ?>
          <?php  if ($num_rows_am_dm_list > 0){  ?>
          <i class="fa fa-angle-down" style="color:#585151;"></i>
          <?php } ?>
          </a>
          <dl class="treeview-menu">
            <?php $employee_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id.' and department='.$valuesamdm['users']['department'].' and manager_id LIKE "%'.$valuesamdm['users']['username'].'%" and status=0 and user_type=6','order'=>'first_name'));
			foreach($employee_list as $key=>$valuesemployee)
			 { 
			  $ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'YEAR(assesment_month) = YEAR(CURRENT_DATE()) AND MONTH(assesment_month) = MONTH(CURRENT_DATE()) AND emp_id='.$valuesemployee['users']['user_id'].' and business_unit='.$bu_id.' and department='.$valuesamdm['users']['department'].' and supervisor_detail ='.$valuesamdm['users']['user_id'].''));
			if(empty($ews_detail)) { 
			 ?>
            <dd style="overflow:hidden;"><span class="glyphicon glyphicon-unchecked text-red" aria-hidden="true"></span>&nbsp;<a href="javascript: void(0);" data-toggle="tooltip" title="<?php echo $valuesemployee['users']['first_name'].' '. $valuesemployee['users']['last_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?>" style="color:#000000!important;"><?php echo $valuesemployee['users']['first_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?></a></dd>
            <?php } else { ?>
            <dd style="overflow:hidden;"><span class="glyphicon glyphicon-check text-green" aria-hidden="true"></span>&nbsp;<a href="javascript: void(0);" data-toggle="tooltip" title="<?php echo $valuesemployee['users']['first_name'].' '. $valuesemployee['users']['last_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?>" style="color:#000000!important;"><?php echo $valuesemployee['users']['first_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?></a></dd>
            <?php  }
		  } ?>
          </dl>
        </dd>
        <?php
			 } ?>
      </dl>
      <?php } ?>
      <?php  $employee_list= $mysql->select(array('table'=>'users','fields'=>'*','condition'=>'business_unit='.$bu_id.' and manager_id LIKE "%'.$manager_id.'%" and status=0 and user_type=6','order'=>'first_name'));
								 if(!empty($employee_list)) {   ?>
      <dl>
        <?php 
								  foreach($employee_list as $key=>$valuesemployee)
									 {
									$ews_detail= $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'YEAR(assesment_month) = YEAR(CURRENT_DATE()) AND MONTH(assesment_month) = MONTH(CURRENT_DATE()) AND emp_id='.$valuesemployee['users']['user_id'].' and business_unit='.$bu_id.' and supervisor_detail ='.$supervisor_detail.''));
									   if(empty($ews_detail)) { ?>
        <dd style="overflow:hidden;"><span class="glyphicon glyphicon-unchecked text-red" aria-hidden="true"></span>&nbsp;<a href="javascript: void(0);" data-toggle="tooltip" title="<?php echo $valuesemployee['users']['first_name'].'&nbsp;'. $valuesemployee['users']['last_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?>" style="color:#000000!important;">&nbsp;<?php echo $valuesemployee['users']['first_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?></a></dd>
        <?php } else { ?>
        <dd style="overflow:hidden;"><span class="glyphicon glyphicon-check text-green" aria-hidden="true"></span>&nbsp;<a href="javascript: void(0);" data-toggle="tooltip" title="<?php echo $valuesemployee['users']['first_name'].'&nbsp;'. $valuesemployee['users']['last_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?>" style="color:#000000!important;">&nbsp;<?php echo $valuesemployee['users']['first_name']."&nbsp;(".$valuesemployee['users']['username'].")"; ?></a></dd>
        <?php  }
		  } ?>
      </dl>
      <?php } ?>
    </div>
    <!-- /.box-body -->
  </div>
</aside>
