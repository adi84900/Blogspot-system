<?php
	//////////////////// Get total Num of records /////////////////////////
						  $ews_detail=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
						    $count_r_r=0;
							$count_r_y=0;
							$count_r_g=0;
							$colors_r=0;
							$colors_y=0;
							$colors_g=0;
						  foreach($ews_detail as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								    /*if($events_detail_total <= 23)
									{
									$colors_r="#FF0000";
									$count_r_r=$count_r_r+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$colors_y="#FF9933";
									$count_r_y=$count_r_y+1;
									}
									else if($events_detail_total >= 30)
									{
									$colors_g="#006600";
									$count_r_g=$count_r_g+1;
									}*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$colors_r="#FF0000";
									$count_r_r=$count_r_r+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$colors_y="#FF9933";
									$count_r_y=$count_r_y+1;
									}
									else if($events_detail_total >= 30)
									{
									$colors_g="#006600";
									$count_r_g=$count_r_g+1;
									}
									
								/*}*/
								}
//////////////////// EOF Get total Num of records /////////////////////////								
//////////////////// Get Num of records of couple of months ago /////////////////////////

							$ews_detail_months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 2 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 2 MONTH)'));
						    $count_r_r_one=0;
							$count_r_y_one=0;
							$count_r_g_one=0;
						  foreach($ews_detail_months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_one=$count_r_r_one+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_one=$count_r_y_one+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_one=$count_r_g_one+1;
									}
									
								/*}*/
								}


//////////////////////End of 2 months ago records /////////////////////////////////	
//////////////////// Get Num of records of Last month/////////////////////////

							$ews_detail_lastmonths=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)'));
						    $count_r_r_two=0;
							$count_r_y_two=0;
							$count_r_g_two=0;
						  foreach($ews_detail_lastmonths as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_two=$count_r_r_two+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_two=$count_r_y_two+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_two=$count_r_g_two+1;
									}
									
								/*}*/
								}


//////////////////////End of last month  records /////////////////////////////////	
//////////////////// Get Num of records of Current month/////////////////////////

							$ews_detail_currentmonths=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE())
							and MONTH(assesment_month) = MONTH(CURRENT_DATE())'));
						    $count_r_r_three=0;
							$count_r_y_three=0;
							$count_r_g_three=0;
						  foreach($ews_detail_currentmonths as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_three=$count_r_r_three+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_three=$count_r_y_three+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_three=$count_r_g_three+1;
									}
									
								/*}*/
								}


//////////////////////End of Current months records /////////////////////////////////
//////////////////// Get Num of records of 11 months ago /////////////////////////

							$ews_detail_11months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 11 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 11 MONTH)'));
						    $count_r_r_twelve=0;
							$count_r_y_twelve=0;
							$count_r_g_twelve=0;
						  foreach($ews_detail_11months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_twelve=$count_r_r_twelve+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_twelve=$count_r_y_twelve+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_twelve=$count_r_g_twelve+1;
									}
									
								/*}*/
								}


//////////////////////End of 11 months ago records /////////////////////////////////		
//////////////////// Get Num of records of 10 months ago /////////////////////////

							$ews_detail_10months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 10 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 10 MONTH)'));
						    $count_r_r_eleven=0;
							$count_r_y_eleven=0;
							$count_r_g_eleven=0;
						  foreach($ews_detail_10months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_eleven=$count_r_r_eleven+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_eleven=$count_r_y_eleven+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_eleven=$count_r_g_eleven+1;
									}
									
								/*}*/
								}


//////////////////////End of 10 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 9 months ago /////////////////////////

							$ews_detail_9months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 9 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 9 MONTH)'));
						    $count_r_r_ten=0;
							$count_r_y_ten=0;
							$count_r_g_ten=0;
						  foreach($ews_detail_9months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_ten=$count_r_r_ten+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_ten=$count_r_y_ten+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_ten=$count_r_g_ten+1;
									}
									
								/*}*/
								}


//////////////////////End of 9 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 8 months ago /////////////////////////

							$ews_detail_8months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 8 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 8 MONTH)'));
						    $count_r_r_nine=0;
							$count_r_y_nine=0;
							$count_r_g_nine=0;
						  foreach($ews_detail_8months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_nine=$count_r_r_nine+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_nine=$count_r_y_nine+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_nine=$count_r_g_nine+1;
									}
									
								/*}*/
								}


//////////////////////End of 8 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 7 months ago /////////////////////////

							$ews_detail_7months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 7 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 7 MONTH)'));
						    $count_r_r_eight=0;
							$count_r_y_eight=0;
							$count_r_g_eight=0;
						  foreach($ews_detail_7months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_eight=$count_r_r_eight+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_eight=$count_r_y_eight+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_eight=$count_r_g_eight+1;
									}
									
								/*}*/
								}


//////////////////////End of 7 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 6 months ago /////////////////////////

							$ews_detail_6months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 6 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 6 MONTH)'));
						    $count_r_r_seven=0;
							$count_r_y_seven=0;
							$count_r_g_seven=0;
						  foreach($ews_detail_9months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_seven=$count_r_r_seven+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_seven=$count_r_y_seven+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_seven=$count_r_g_seven+1;
									}
									
								/*}*/
								}


//////////////////////End of 6 months ago records /////////////////////////////////		
//////////////////// Get Num of records of 5 months ago /////////////////////////

							$ews_detail_5months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 5 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 5 MONTH)'));
						    $count_r_r_six=0;
							$count_r_y_six=0;
							$count_r_g_six=0;
						  foreach($ews_detail_5months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_six=$count_r_r_six+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_six=$count_r_y_six+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_six=$count_r_g_six+1;
									}
									
								/*}*/
								}


//////////////////////End of 5 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 4 months ago /////////////////////////

							$ews_detail_4months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 4 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 4 MONTH)'));
						    $count_r_r_five=0;
							$count_r_y_five=0;
							$count_r_g_five=0;
						  foreach($ews_detail_4months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_five=$count_r_r_five+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_five=$count_r_y_five+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_five=$count_r_g_five+1;
									}
									
								/*}*/
								}


//////////////////////End of 4 months ago records /////////////////////////////////	
//////////////////// Get Num of records of 3 months ago /////////////////////////

							$ews_detail_3months=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].' and YEAR(assesment_month) = YEAR(CURRENT_DATE - INTERVAL 5 MONTH)
							and MONTH(assesment_month) = MONTH(CURRENT_DATE - INTERVAL 5 MONTH)'));
						    $count_r_r_four=0;
							$count_r_y_four=0;
							$count_r_g_four=0;
						  foreach($ews_detail_3months as $key=>$value)
								{
								
								$empid=$value['ews_detail']['emp_id'];
								$empstatus=$mysql->get('users','status','user_id='.$empid);
								$status= $value['ews_detail']['status'];
								/*if($empstatus==0)
								{*/
								$events_detail_total=$value['ews_detail']['one_on_one_ass']+$value['ews_detail']['performance']+$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['behavior_motivation']+$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['career_growth']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 23)
									{
									$count_r_r_four=$count_r_r_four+1;
									}
									else if($events_detail_total  >= 24 && $events_detail_total  <= 29)
									{
									$count_r_y_four=$count_r_y_four+1;
									}
									else if($events_detail_total >= 30)
									{
									$count_r_g_four=$count_r_g_four+1;
									}
									
								/*}*/
								}


//////////////////////End of 3 months ago records /////////////////////////////////	
//////////////////// Get Num of records for  gauge chart first /////////////////////////
$ews_detail=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
$num_rows_gauge_one = $mysql->countRows(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
						    $count_r_r_gaugeone=0;
							$count_r_y_gaugeone=0;
							$count_r_g_gaugeone=0;
						  foreach($ews_detail as $key=>$value)
								{
								  $events_detail_total=$value['ews_detail']['performance']+$value['ews_detail']['skill_set']+$value['ews_detail']['criticality_check'];
									if($events_detail_total <= 7)
									{
									  $count_r_r_gaugeone=$count_r_r_gaugeone+1;
									}
									else if($events_detail_total  >= 8 && $events_detail_total  <= 10)
									{
									  $count_r_y_gaugeone=$count_r_y_gaugeone+1;
									}
									else if($events_detail_total >= 10)
									{
									  $count_r_g_gaugeone=$count_r_g_gaugeone+1;
									}
								}

//echo $num_rows_gauge_one.'======'.$count_r_r_gaugeone.'+++++'.$count_r_y_gaugeone.'-------'.$count_r_g_gaugeone;
//////////////////////End of  gauge chart first records /////////////////////////////////
//////////////////// Get Num of records for  gauge two first /////////////////////////
$ews_detail=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
$num_rows_gauge_two = $mysql->countRows(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
						    $count_r_r_gaugetwo=0;
							$count_r_y_gaugetwo=0;
							$count_r_g_gaugetwo=0;
						  foreach($ews_detail as $key=>$value)
								{
								  $events_detail_total=$value['ews_detail']['personal_effectiveness']+$value['ews_detail']['skill_set'];
									if($events_detail_total <= 5)
									{
									  $count_r_r_gaugetwo=$count_r_r_gaugetwo+1;
									}
									else if($events_detail_total  >= 6 && $events_detail_total  <= 8)
									{
									  $count_r_y_gaugetwo=$count_r_y_gaugetwo+1;
									}
									else if($events_detail_total >= 9)
									{
									  $count_r_g_gaugetwo=$count_r_g_gaugetwo+1;
									}
								}

//echo $num_rows_gauge_one.'======'.$count_r_r_gaugetwo.'+++++'.$count_r_y_gaugetwo.'-------'.$count_r_g_gaugetwo;
//////////////////////End of  gauge chart first records /////////////////////////////////	
//////////////////// Get Num of records for  gauge chart third /////////////////////////
$ews_detail=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
$num_rows_gauge_three = $mysql->countRows(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].' and supervisor_detail='.$_SESSION['userid'].''));
						    $count_r_r_gaugethree=0;
							$count_r_y_gaugethree=0;
							$count_r_g_gaugethree=0;
						  foreach($ews_detail as $key=>$value)
								{
								  $events_detail_total=$value['ews_detail']['leave_r']+$value['ews_detail']['external_interviews']+$value['ews_detail']['career_growth'];
									if($events_detail_total <= 7)
									{
									  $count_r_r_gaugethree=$count_r_r_gaugethree+1;
									}
									else if($events_detail_total  >= 8 && $events_detail_total  <= 10)
									{
									  $count_r_y_gaugethree=$count_r_y_gaugethree+1;
									}
									else if($events_detail_total >= 10)
									{
									  $count_r_g_gaugethree=$count_r_g_gaugethree+1;
									}
								}

//echo $num_rows_gauge_one.'======'.$count_r_r_gaugeone.'+++++'.$count_r_y_gaugeone.'-------'.$count_r_g_gaugeone;
//////////////////////End of  gauge chart third records /////////////////////////////////				
	  ?>

<div class="row">
  <div class="col-md-4 col-sm-6 col-xs-12">
    <div class="info-box bg-red"> <span class="info-box-icon"><i class="ion ion-sad-outline"></i></span>
      <div class="info-box-content"> <span class="info-box-text">High Risk</span> <span class="info-box-number"><?php echo $count_r_r; ?></span>
        <div class="progress">
          <div class="progress-bar" style="width:90%"></div>
        </div>
        <!-- <span class="progress-description"> 90% Accuracy&nbsp; | &nbsp;-->
        <a href="<?php echo BASE_URL; ?>/manage_ews.php?emp_id=&ews_status=1&assesment_month=&fromdate_filter=&todate_filter=&filter_submit=" style="color:#FFFFFF;">More info <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  <div class="col-md-4 col-sm-6 col-xs-12">
    <div class="info-box bg-yellow"> <span class="info-box-icon"><i class="ion ion-android-sad"></i></span>
      <div class="info-box-content"> <span class="info-box-text">Medium Risk</span> <span class="info-box-number"><?php echo $count_r_y; ?></span>
        <div class="progress">
          <div class="progress-bar" style="width: 70%"></div>
        </div>
        <!--<span class="progress-description"> 70% Accuracy&nbsp; | &nbsp;-->
        <a href="<?php echo BASE_URL; ?>/manage_ews.php?emp_id=&ews_status=2&assesment_month=&fromdate_filter=&todate_filter=&filter_submit=" style="color:#FFFFFF;">More info <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  <div class="col-md-4 col-sm-6 col-xs-12">
    <div class="info-box bg-green"> <span class="info-box-icon"><i class="ion ion-happy-outline"></i></span>
      <div class="info-box-content"> <span class="info-box-text">Low Risk</span> <span class="info-box-number"><?php echo $count_r_g; ?></span>
        <div class="progress">
          <div class="progress-bar" style="width: 100%"></div>
        </div>
        <!--<span class="progress-description"> 100% Accuracy&nbsp; | &nbsp;-->
        <a href="<?php echo BASE_URL; ?>/manage_ews.php?emp_id=&ews_status=3&assesment_month=&fromdate_filter=&todate_filter=&filter_submit=" style="color:#FFFFFF;">More info <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
    </div>
  </div>
  
  <div class="col-md-12">
    <div class="box box-success">
      <div class="box-header with-border" style="text-align:center;">
        <h3 class="box-title">Retention Trends</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
        </div>
        <!-- /.box-tools -->
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
	   <div id="chartdivtrends" style="width: 100%; height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
  </div>
  <div class="col-md-12">
    <div class="box box-success">
      <div class="box-header with-border" style="text-align:center;">
        <h3 class="box-title">Retention Analytics</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
        </div>
        <!-- /.box-tools -->
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
	  <div class="col-md-4 col-sm-8 col-xs-12">
          <div id="chartdiv_gauge" style="width: 100%; height: 280px;"></div>
		  <h5 align="center">Performance + Skill Set + Criticality</h5>
        </div>
	  <div class="col-md-4 col-sm-8 col-xs-12">
          <div id="chartdiv_gauge_two" style="width: 100%; height: 280px;"></div>
		  <h5 align="center">Personal Effectiveness + Skill Set</h5>
        </div>
	  <div class="col-md-4 col-sm-8 col-xs-12">
          <div id="chartdiv_gauge_three" style="width: 100%; height: 280px;"></div>
		  <h5 align="center">Leave + External Interviews +  Career Growth</h5>
        </div>		
      </div>
      <!-- /.box-body -->
    </div>
  </div>
  <div class="col-md-12">
    <div class="box box-success">
      <div class="box-header with-border" style="text-align:center;">
        <h3 class="box-title">Retention Last Three Months</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
        </div>
        <!-- /.box-tools -->
      </div>
      <!-- /.box-header -->
      <div class="box-body" style=" height: 300px;">
        <?php if($count_r_g_three!='') { ?>
        <div class="col-md-4 col-sm-8 col-xs-12">
          <h4 align="center"><?php echo date('F, Y', strtotime('first day of this month'));?></h4>
          <div id="chartdivpie_three" style="height:230px;"></div>
        </div>
        <?php } ?>
        <?php if($count_r_g_two!='') { ?>
        <div class="col-md-4 col-sm-8 col-xs-12">
          <h4 align="center"><?php echo date('F, Y', strtotime('first day of -1 month'));?></h4>
          <div id="chartdivpie_two" style="height:230px;"></div>
        </div>
        <?php } ?>
        <?php if($count_r_g_one!='') { ?>
        <div class="col-md-4 col-sm-8 col-xs-12">
          <h4 align="center"><?php echo date('F, Y', strtotime('first day of -2 month'));?></h4>
          <div id="chartdivpie_one" style="height:230px;"></div>
        </div>
        <?php } ?>
       <?php /*?> <?php if($count_r_g!='') { ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <h4 align="center">All</h4>
          <div id="chartdivpie" style="height:250px;"></div>
        </div>
        <?php } ?><?php */?>
      </div>
      <!-- /.box-body -->
    </div>
  </div>
   <div class="col-md-6">
          <div class="box box-success">
            <div class="box-header with-border" style="text-align:center;">
              <h3 class="box-title">1 ON 1 Assessment</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <div id="chartdiv_oneonone" style="height:400px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
   <div class="col-md-6">
          <div class="box box-success">
            <div class="box-header with-border" style="text-align:center;">
              <h3 class="box-title">Behavior/ Motivation</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <div id="chartdiv_rating_behave" style="height:400px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
  <?php $ews_detail_lastmonths_high=  $mysql->select(array('table'=>'ews_detail','fields'=>'*','condition'=>'business_unit='.$_SESSION['business_unit'].'  and status=1 and supervisor_detail='.$_SESSION['userid'].' AND YEAR(assesment_month) = YEAR(CURRENT_DATE()) and MONTH(assesment_month) = MONTH(CURRENT_DATE())','order'=>'created_date DESC'));
		if(!empty($ews_detail_lastmonths_high)) { ?>
  <div class="col-md-12">
    <div class="box box-danger">
      <div class="box-header with-border" style="text-align:center;">
        <h3 class="box-title">High Risk : Month <?php echo date('F, Y', strtotime('first day of this month'));?></h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
        </div>
        <!-- /.box-tools -->
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding" style="height:200px;">
        <table class="table table-hover table-fixed table-bordered">
          <thead>
            <tr>
              <th width="30%">Employee Name</th>
              <th width="70%">Comment/Remark</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($ews_detail_lastmonths_high as $key=>$value)
					  { 
								$empid=$value['ews_detail']['emp_id'];
								$empfirst_name=$mysql->get('users','first_name','user_id='.$empid);
								$emplast_name=$mysql->get('users','last_name','user_id='.$empid);
								$empusername=$mysql->get('users','username','user_id='.$empid);
								$comment=$value['ews_detail']['comment'];
								if($comment!='') {
								 $comment_new=$comment;
								}else{
								 $comment_new='N/A';
								}
								?>
            <tr height="20px">
              <td width="30%"><?php echo $empfirst_name.'&nbsp;'.substr($emplast_name,0,6).'&nbsp;('.$empusername.')'; ?></td>
              <td width="70%"><?php echo limit_text($comment_new,50); ?><br /></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
  </div>
  <?php } ?>
  <!--<div class="col-md-6">
    <div class="box box-success">
      <div class="box-header with-border" style="text-align:center;">
        <h3 class="box-title"><?php echo 'January, '.date('Y');?> To Till Now</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
        </div>
      </div>
      <div class="box-body table-responsive no-padding">
        <div class="accordion-inner">
          <div id="chartdiv" style="height:300px;"></div>
        </div>
      </div>
    </div>
  </div>-->
</div>



