<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Panels Model
 *
 * @property \App\Model\Table\ComplaintUsersTable|\Cake\ORM\Association\BelongsTo $ComplaintUsers
 * @property \App\Model\Table\SupervisorsTable|\Cake\ORM\Association\BelongsTo $Supervisors
 *
 * @method \App\Model\Entity\Panel get($primaryKey, $options = [])
 * @method \App\Model\Entity\Panel newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Panel[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Panel|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Panel|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Panel patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Panel[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Panel findOrCreate($search, callable $callback = null, $options = [])
 */
class PanelsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('panels');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

      
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');


          $validator
            ->integer('complaint_user_id')
            ->allowEmpty('complaint_user_id', 'create');

        $validator
            ->scalar('p_empid')
            ->maxLength('p_empid', 50)
            ->allowEmpty('p_empid');

        $validator
            ->scalar('p_name')
            ->maxLength('p_name', 50)
            ->allowEmpty('p_name');

        $validator
            ->scalar('p_email')
            ->maxLength('p_email', 200)
            ->allowEmpty('p_email');

        $validator
            ->scalar('p_scribe')
            ->maxLength('p_scribe', 50)
            ->allowEmpty('p_scribe');

        $validator
            ->scalar('supervisor_name')
            ->maxLength('supervisor_name', 100)
            ->allowEmpty('supervisor_name');

        $validator
            ->scalar('role')
            ->maxLength('role', 50)
            ->allowEmpty('role');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
       

        return $rules;
    }
}
