<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Users Model
 *
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, callable $callback = null, $options = [])
 */

class HrTable extends Table {

	/**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */

   	public function initialize(array $config){
        parent::initialize($config);
        $this->setTable('users');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
	 	$this->hasOne('Witns');
	}

	//query goes here for counting total number of cases
	public function getTotalCases(){
		$query = $this->find();
		$query->select(['count' => $query->func()->count('id')]);
		$query->where(['c_subject <>' => '']);
		$total = $query->toarray();
		$total_case = $total[0]->count;
		return $total_case;
	}

	//query goes here for counting total number of harshment cases
	public function getTotalHarassmentCase($city='', $startdate='', $enddate=''){
		$case_type = 'Harassment';
		$query = $this->find();
		$query->select(['count' => $query->func()->count('id')]);
		$query->where(['c_subject' => $case_type, ]); //, 'city' => $city
               
		$harassment = $query->toArray();
		$total_harassment = $harassment[0]->count;
		return $total_harassment;
	}

	//query goes here for counting total number of business ethics
	public function getTotalBusinessEthics(){
		$case_type = 'Business Ethics';
		$query = $this->find();
		$query->select(['count' => $query->func()->count('id')]);
		$query->where(['c_subject' => $case_type]);
		$business_ethics = $query->toArray();
		$totalBusinessEthics = $business_ethics[0]->count;
		return $totalBusinessEthics;
	}

	//query goes here for conting total number of Disiplinary
	public function getTotalDisiplinary(){
		$case_type = 'Disciplinary';
		$query = $this->find();
		$query->select(['count' => $query->func()->count('id')]);
		$query->where(['Hr.c_subject' => $case_type]);
		$disiplinary = $query->toArray();
		$toatl_disiplinary = $disiplinary[0]->count;
		return $toatl_disiplinary;
	}

	//query goes here for getting total cities
	public function getCities(){
		$query = $this->find();
		$query->select(['city'])
			  ->distinct(['city'])
			  ->where(['city <>' => ''])
			  ->order(['city']);
		$city = $query->toArray();	
		return $city;
	}
        
        //query goes here for getting according to filter city and datewise
        public function getFilterharassment($city='', $startdate='', $enddate=''){
        }
}

?>