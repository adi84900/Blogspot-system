<?php
namespace App\Controller;
ob_start();
use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\I18n\Time;
use Cake\Network\Request;
use Cake\View\Form\EntityContext;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Cake\Http\Exception\NotFoundException;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Routing\Router;

/**
 * Users Controller
 *
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
	  

  public function beforeFilter(Event $event)
    {
		$this->loadComponent('Flash');     
        parent::beforeFilter($event);
        // Allow users to register and logout.
        // You should not add the "login" action to allow list. Doing so would
        // cause problems with normal functioning of AuthComponent.
        $this->Auth->allow(['login', 'logout']);
    }
	  public function index()
     {
		 $user = $this->Auth->user();
        //$this->set('users', $this->Users->find('all'));
    }

	public function login()
    {
		$this->viewBuilder()->layout('layout');
		$this->loadModel('Users');
        if ($this->request->is('post')) {
            //$user = $this->Auth->identify();
  $user = $this->Auth->identify($this->request->data);
            if ($user) {
                $this->Auth->setUser($user);
				
				 $session = $this->request->session();
                $session->write('curUser', $this->Auth->user());
			$user_fetchrecord=$this->Users->find('all')->where(array('id' => $user['id']))->toArray();
				$this->redirecturlafterlogin();
                //return $this->redirect($this->Auth->redirectUrl());
            }
            $this->Flash->error(__('Invalid Email Id or Password, try again'));
        }
	 $this->set(compact('user','user_fetchrecord'));
    }
	
	public function redirecturlafterlogin()
    {
		
		//$this->viewBuilder()->layout('');
		 $user = $this->Auth->user();
                   $session = $this->request->session();
		 	$user_fetchrecord=$this->Users->find('all')->where(array('id' => $user['id']))->toArray();
                      $id=$user['id'];
                         $user_email=$user['email'];
                         $useremail= $session->write('user_email',  $user_email);

 switch ($user['role']) {
            case 'Accuser':
                $this->viewBuilder()->layout('userlayout');
             $user_fetchrecord=$this->Users->find('all')->where(array('id' => $user['id']))->toArray();
return $this->redirect(['controller'=>'Users','action'=>'userprofile',$id]);
                break;

            case 'Supervisor':
 $session = $this->request->session();
$userid= $session->write('userid',  $id);
                $this->viewBuilder()->layout('');
                return $this->redirect(['controller' => 'Supervisor', 'action' => 'dashboard',$userid]);
                break;
 case 'Hr':
 $session = $this->request->session();
$useremail= $session->write('user_email',  $user_email);
                $this->viewBuilder()->layout('');
                return $this->redirect(['controller' => 'Hr', 'action' => 'dashboard']);
                break;



}

    }
	
	  public function logout()
    {
		 $session = $this->request->session();
        $session->destroy();
        return $this->redirect($this->Auth->logout());
    }
	/**
         * After login user will show his profile data.
  */
	 public function userprofile($id = null)
    {
	$this->viewBuilder()->layout('userlayout');
$this->loadModel('Complaints');
  $session = $this->request->session();
$useremailid = $session->read('user_email');
	 $user_deatil=$this->Users->find('all')->where(array('id' => $id))->toArray();
$user_complaint_deatil=$this->Users->find('all')->where(array('Users.user_id' => $id,'Users.complaint_id_status' => '1'))->toArray();




$user_complaint_superwisor_deatil=$this->Complaints->find('all')->where(array('Complaints.complaint_id' => $id))->toArray();
//pr($id);die;
           $this->set(compact('id','user_deatil','useremailid','user_complaint_deatil','user_complaint_superwisor_deatil'));
		}
	
public function userComplaintDetails($userid = null)
    {
$this->loadModel('Witns');
		$this->viewBuilder()->layout('userlayout');
 $user_deatil=$this->Users->find('all')->where(array('id' => $userid))->toArray();
$user_complaint_deatil=$this->Users->find('all')->where(array('Users.id' => $userid))->toArray();
  $witness_user_detail=$this->Witns->find()->where(['Witns.user_complaint_id' => $userid]);
 $this->set(compact('user_complaint_deatil','user_deatil','witness_user_detail'));
}




/**
         * After Supervisor  login it can see  user profile data .
  */
	 public function messages()
    {
	$this->viewBuilder()->layout('backendlayout');
	 $user_detail=$this->Users->find('all')->toArray();
         
	  $this->set(compact('id','user_detail'));
		}




/**
         * After Supervisor  login it can search  user profile data from users table .
  */
	 public function profiles()
    {
$session = $this->request->session();
$useremailid = $session->read('user_email');
                	$this->viewBuilder()->layout('backendlayout');
                  	 $user_profile_detail=$this->Users->find('all')->where(['Users.email' =>  $useremailid])->toArray();
         	  $this->set(compact('user_profile_detail'));
		}



/**
         * After Supervisor  login it can search  user profile data from users table .
  */
	 public function reportsearch()
    {
                 $this->loadModel('Users');
	$this->viewBuilder()->layout('');
$search=$this->request->data('search');
               $user_detail_search=$this->Users->find('all')->where(['Users.complaint_id' => $search])
->orWhere(['Users.first_access' => $search]);
$this->set('user_detail_search', $this->paginate($user_detail_search));

 return $this->redirect(['controller'=>'Users','action'=>'reports',$search]);
		}
/**
         * After Supervisor  login it can search  user profile data from users table .
  */
	 public function complaintDetails($id = null)
    {
                 $this->loadModel('Users');
              $this->loadModel('Witns');
	$this->viewBuilder()->layout('backendlayout');
        $individual_user_detail=$this->Users->find()->where(['Users.id' => $id])->toArray();
        $individual_user_detail_email=$this->Users->find()->where(['Users.id' => $id])->toArray();
        //$individual_user_detail_emailid=$emailid;
        $witness_user_detail=$this->Witns->find()->where(['Witns.user_id' => $id]);
//pr($witness_user_detail);die;
        $this->set('individual_user_detail', $individual_user_detail);
 $this->set('witness_user_detail', $witness_user_detail);
  
$tablename = TableRegistry::get("Users");
$updatestatus = $tablename->get($id);
$updatestatus->status = 'Accept';
if ($tablename->save($updatestatus)) {

}

		}



/**
         * After Supervisor  login it can search  user profile data from users table .
  */
	 public function addUser()
    {
                 $this->loadModel('Users');
	$this->viewBuilder()->layout('admin_backend_layout');
$a = (string) microtime();
if ($this->request->is('post')) {
                   $name=$this->request->data('name');
$username=$this->request->data('name');
$bu=$this->request->data('bu');
$city=$this->request->data('city');
$work_location=$this->request->data('work_location');
$empid=$this->request->data('empid');
$email=$this->request->data('email');
$mobile=$this->request->data('mobile');
$user_type=$this->request->data('user_type');
$password=$this->request->data('password');
$pass=$this->request->data('password');
$position=$this->request->data('position');
$usersTable = TableRegistry::get('users');
$usersdata = $usersTable->newEntity();

$usersdata->work_location  =$work_location ;
$usersdata->name = $name;
$usersdata->username = $username;
$usersdata->user_type = $user_type;
$usersdata->password = $password;
$usersdata->pass = $pass;
$usersdata->empid = $empid;
$usersdata->email =$email; 
$usersdata->mobile =$mobile; 
$usersdata->bu =$bu; 
$usersdata->city =$city; 
$usersdata->position =$position;

         if ($usersTable->save($usersdata)) {
$this->Flash->success(__('User  has been successfully saved.'));
}

}	  
		}

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);

        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
   public function signup()
    {
		$this->viewBuilder()->layout('');
 $this->loadModel('Users');
		$ip =  $this->request->clientIp();
		$time = Time::now();
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
				//pr($user);die;
                //$this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'sineupSuccess']);
            }
            $this->Flash->error(__('The user could not be registered Some thing error.'));
        }
        $this->set(compact('user','ip','time'));
    }


 public function sineupSuccess()
    {
		$this->viewBuilder()->layout('');
}
	 public function add()
    {
		$this->viewBuilder()->layout('');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

	
    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'userprofile']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
	
 


    public function registerConcern($id = null){
            
            //query for counting total no of witness
            $count_witness_name = '';
            if(!empty($_POST['wi_name'])){
            $count_witness_name = count($_POST['wi_name']);
            }
            
            //query for counting total no of accused
            $count_accused_name = '';
            if(!empty($_POST['accused_name'])){
            $count_accused_name = count($this->request->data['accused_name']);
            }
            
            $data = $this->getcategory();
            $this->set('catdata',$data);
      
            //query for counting total no of files
            $count = '';
            if(!empty($_FILES)){
                $count = count($_FILES['image']['name']);
            }
            
            $this->loadModel('Witns');		
            $time1 = Time::now();
            $time = Time::now();
            $a = (string) microtime();
            $this->viewBuilder()->layout('');
            $this->loadModel('Users');

             $individual_registered_user_detail=$this->Users->find()->where(['Users.id' => $id])->toArray();

            if ($this->request->is('post')) {
            //pr($this->request->data);die;
            $c_title=$this->request->data['c_title'];
            $concern_regarding=$this->request->data['category_concern'];
            $other_issue=$this->request->data['category_concern_sub'];
            $colleague_complaint=$this->request->data['c_option'];
            $resolve_complaint=$this->request->data['c_tried_r_own'];
            $bu=$this->request->data('bu');
            $city=$this->request->data('city');
            $work_location=$this->request->data['work_location'];
            $name=$this->request->data('name');

            $user_type=$this->request->data('user_type');


            $empid=$this->request->data['empid'];
            $email=$this->request->data('email');
            $mobile=$this->request->data('mobile');
            $notes=$this->request->data('notes');
            $concern_details=$this->request->data('concern_details');
            $attach_data =$this->request->data('attach_data');
            $attach_data_imploed=implode(",",$attach_data);


            $confirmed=$this->request->data('confirmed');
            $complaint_id_status=$this->request->data('complaint_id_status');
            $complaint_id_genrate_date=$this->request->data('complaint_id_genrate_date');

            $status=$this->request->data('status');
            $usersTable = TableRegistry::get('users');
            $user_id=$this->request->data('user_id');
            $usersdata = $usersTable->newEntity();
            $usersdata->c_title  =$c_title ;
            $usersdata->c_subject = $concern_regarding;
            $usersdata->other_issue = $other_issue;
            $usersdata->c_option =$colleague_complaint; 
            $usersdata->c_tried_r_own =$resolve_complaint; 
            $usersdata->bu =$bu; 
            $usersdata->city =$city; 
            $usersdata->work_location  =$work_location ;
            $usersdata->name = $name;

            $usersdata->user_type = $user_type;

            $usersdata->empid = $empid;
            $usersdata->email =$email; 
            $usersdata->mobile =$mobile; 
            $usersdata->notes =$notes; 
            $usersdata->concern_details =$concern_details; 
            $usersdata->attach_data =$attach_data_imploed; 

            $complaint_id = "MV" . substr($a, 2, 4);
            $usersdata->complaint_id =$complaint_id; 

            $usersdata->confirmed =$confirmed; 
            $usersdata->status =$status; 
            $usersdata->complaint_id_status =$complaint_id_status;

            $usersdata->complaint_id_genrate_date =$complaint_id_genrate_date;
            $usersdata->user_id =$user_id;
            if ($usersTable->save($usersdata)) {

             $id = $usersdata->id;
             
                 //query for inserting images
                if($count > 0){
                    for($i=0; $i<$count; $i++){
                        //get the temp file path
                        $temFilePath = $_FILES['image']['tmp_name'][$i];
                        //make sure you have file
                        if($temFilePath != ''){
                            //set our new file path
                            $fileName[] = $_FILES['image']['name'][$i];
                            $files = time()."_".str_replace("", "_", $_FILES['image']['name'][$i]);
                            $newFilePath = WWW_ROOT.DS.'upload'.DS.$files;
                            $imageTable = TableRegistry::get('images');
                            $imageData = $imageTable->newEntity();
                            if(move_uploaded_file($temFilePath, $newFilePath)){
                               $imageData->user_id  = $id ;
                               $imageData->image    = $files ;
                               $imageTable->save($imageData);
                            }
                        }
                    }
               }
               
               //query for inserting witness data
               if($count_witness_name > 0){
                for($i=0; $i<$count_witness_name; $i++){
                    $witnessName = $_POST['wi_name'][$i];
                    $witnessBusiness = $_POST['wi_bu'][$i];
                    $witnessEmpid = $_POST['wi_empid'][$i];
                    $witnessLocation = $_POST['wi_location'][$i];
                    $witnessEmailid = $_POST['wi_email_id'][$i];
                    $witnessRelationship = $_POST['relationship'][$i];
                    $witnessCity = $_POST['wi_city'][$i];
                    $witnsTable = TableRegistry::get('witns');
                    $witns = $witnsTable->newEntity();
                    
                    $witns->wi_name  = (string)$witnessName ;
                    $witns->wi_bu = (string)$witnessBusiness;
                    $witns->wi_city = (string)$witnessCity;
                    $witns->wi_location = (string)$witnessLocation; 
                    $witns->wi_empid = (string)$witnessEmpid; 
                    $witns->wi_email_id = (string)$witnessEmailid; 
                    $witns->relationship = (string)$witnessRelationship;
                    $witns->user_id = $user_id;
                    $witns->user_complaint_id = $id;
//                    
                    $witnsTable->save($witns);
                }
            }
            
            
            //query for inserting accused data
                if($count_accused_name > 0){
                for($i=0; $i<$count_accused_name; $i++){
                    $accusedName = $this->request->data['accused_name'][$i];
                    $accusedBusiness = $this->request->data['accused_bu'][$i];
                    $accusedEmpid = $this->request->data['accused_empid'][$i];
                    $accusedLocation = $this->request->data['accused_location'][$i];
                    $accusedEmailid = $this->request->data['accused_email_id'][$i];
                    $accusedCity = $this->request->data['accused_city'][$i];
                    $accusedDept = $this->request->data['accused_dept'][$i];
                    $accusedTable = TableRegistry::get('accused');
                    $accused = $accusedTable->newEntity();
                    
                    $accused->accused_name  = (string)$accusedName ;
                    $accused->accused_bu = (string)$accusedBusiness;
                    $accused->accused_city = (string)$accusedCity;
                    $accused->accused_location = (string)$accusedLocation; 
                    $accused->accused_empid = (string)$accusedEmpid; 
                    $accused->accused_email_id = (string)$accusedEmailid; 
                    $accused->accused_dept = (string)$accusedDept;
                    $accused->user_id = $user_id;
                    $accused->complaint_id = $id;
//                    
                    $accusedTable->save($accused);
                }
            }


            $tablename = TableRegistry::get("witns");
            $query = $tablename->query();
                        $result = $query->update()
                                ->set(['witns.user_complaint_id' => $id,'witns.user_id' => $user_id])
                                ->where(['witns.a_useremail' => $email,'witns.user_concern_details' =>$concern_details])
                                ->execute();

            return $this->redirect([ 'controller'=>'Users','action' => 'concern','complaint_id'=>$complaint_id]);

                       }

             }
            $this->set(compact('time1','complaint_id','complaint_id_data','individual_registered_user_detail','time'));

    }

 public function concern()
    {
		$this->loadModel('Users');
		 //$complaint_id= $this->Users->get($id, [
            //'contain' => []
        //]);
		//$complaint_id1 = $this->Users->find('all', array('order'=> 'Users.id DESC' ));

       
	}

	public function changepassword($id=null)
    {    
        $this->loadModel('Users');
     $this->viewBuilder()->layout('changepasswordlayout');

     if ($this->request->is('post')) {
       $this->loadModel('Users');
    $session = $this->request->session();
    $session_data=$session->read();
    $user_id = $session_data["Auth"]["User"]["id"];
    $this->viewBuilder()->layout('changepasswordlayout');
     if ($this->request->is('post')) {
        
        $password = $this->request->data['new_password'];
        $password1 = $this->request->data['new_password'];
        $hasher = new DefaultPasswordHasher();
        $password=$hasher->hash($password);
        $connection = ConnectionManager::get('default');
        $connection->update('users', ['password' => $password], ['id' => $user_id]);
        $connection->update('users', ['pass' => $password1], ['id' => $user_id]);
}
    }
}
	
public function viewuser()
{
    $this->viewBuilder()->layout('');
    $this->loadModel('Users');
   
    $session = $this->request->session();
    $user_id=$session->read('empid');
    $user_detail=$this->Users->find()->where(['Users.confirmed' => 1]);
    $this->set(compact('user_detail'));

    if($this->request->is('ajax')){
         $empid = $this->request->data('empid');
         $user_details2=$this->Users->find()->where(['Users.empid' => $empid]);
         echo(json_encode($user_details2));
          exit;
    
    }

     
}


public function forgotpassword()
{
     $this->viewBuilder()->layout('');

}


public function updateuserdetails()
{
 //if($this->request->is('ajax')){
      
        //if($this->request->is('post'))
        //{
        
        $name=$this->request->data('report_up_name');
        $city=$this->request->data('report_up_city');
        $work_location=$this->request->data('report_up_loc');
        $empid=$this->request->data('report_up_empID');
        $email=$this->request->data('report_up_email');
        $tablename = TableRegistry::get("Users");

        //echo  $name;
        //die;

$conditions = array('empid'=>$empid);
$fields = array('name'=> $name,'city'=>$city,'work_location'=> $work_location);
$tablename->updateAll($fields, $conditions);
        // $query = $tablename->query();
        //     $result = $query->update()
        //             ->set(['name' => $name])
        //             ->where(['empid' => $empid])
        //             ->execute();
    
     //}
//}

}


   private function getcategory()
   {
     $category_table = TableRegistry::get("categories");
     $query = $category_table->find('all');
     
     //$data = $query->toArray();
     $rtn=array();
     foreach ($query as $key => $value) {
        $rtn[$value['category_id']]=$value->toArray();
        }
     return $rtn;
     //$this/*->Anonymous*/->set('data',$data);
     //$this -> render('/Anonymous/anonymousconcern');
    // pr($data);
    
   }

   public function getSubcate(){
    if($this->request->is('post')){
        $data=$this->request->data;
        $selected=$data['sel'];
        $sub_table = TableRegistry::get("sub_category_concern");
        $query = $sub_table->find('all')
                ->where(['category_id'=>$selected]);

        $html='<option value="0" >choose an option</option>';
        foreach ($query as $key => $value) {
           // pr($value);die;
            $html=$html.'<option value="'.$value->id.'" >'.$value->name.'</option>';
        }
        echo json_encode(array('html'=>$html));die; 
    }else{
        echo 'Invalid request';die;
    }
    //echo 'in';die;
   }

 
	
}
