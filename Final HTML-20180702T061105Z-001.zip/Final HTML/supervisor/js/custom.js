$(document).ready(function () {
    $(".btn").on("click",function () {
        $(this).blur();
    });

    $("a").on("click",function () {
        $(this).blur();
    })
});